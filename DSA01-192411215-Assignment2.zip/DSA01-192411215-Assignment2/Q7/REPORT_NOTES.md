# Q7 notes (fill in with YOUR measurements)

Chosen program: Q4 SavingsAccount (fixed array, shift on overflow).

**A. Diagnosis** - add() costs O(N) once the array is full (loop shifting N-1 elements); with N = 10 it is negligible, with N = 50 / 1000 / 5000 it grows linearly. Cause: oldest entry is always at index 0, so every insertion moves all others.

**B. Objective** - make add() time independent of N (O(1)); target: at N = 1000, at least 20x faster than shifting for 200,000 transactions, with identical mini-statement output.

**C. Redesign** - keep the private fixed array, add `start` index; new entry overwrites `last[start]` when full; print from `start` using `(start+i) % N`. No extra memory except one int. Trade-off: slightly more complex printing/index arithmetic; elements no longer contiguous in logical order.

**D. Prediction** - time per add stays flat as N grows for circular; shift time grows about linearly with N (e.g. N=1000 ~ 100x slower than N=10).

**E. Validation** - run `redesign_benchmark.cpp` (-O2) and paste the table; also compare account_shift vs account_circular outputs (identical).

**F. Defence** - objective met if circular time is flat. Original may still be preferable for N <= 10 (simple, contiguous, trivially readable) or when the statement must be printed/copied as one contiguous block very often.

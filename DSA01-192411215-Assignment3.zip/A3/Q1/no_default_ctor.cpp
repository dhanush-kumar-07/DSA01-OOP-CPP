// Q1 experiment: remove the default constructor -> array of Books does not compile.
// EXPECTED: compile ERROR (no matching function for call to 'Book::Book()')
#include <string>
class Book {
    std::string title; int copies;
public:
    Book(std::string t, int c) : title(t), copies(c) {}   // no default constructor
};
int main() {
    Book shelf[3];   // error: needs Book::Book()
    return 0;
}

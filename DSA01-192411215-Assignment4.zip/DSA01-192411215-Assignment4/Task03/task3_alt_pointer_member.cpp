// Task 3 Alternative: Student holds Address* (dynamic) instead of an Address member
#include <iostream>
#include <string>
class Address {
    std::string city; int pin;
public:
    Address(const std::string& c, int p) : city(c), pin(p) {}
    std::string str() const { return city + "-" + std::to_string(pin); }
};
class Person {
protected: std::string name; int age;
public: Person(const std::string& n, int a) : name(n), age(a) {}
};
class Student : public Person {
    long long regNo;
    Address* home;                                              // owned pointer
public:
    Student(const std::string& n, int a, long long r, const std::string& c, int p)
        : Person(n, a), regNo(r), home(new Address(c, p)) {}    // constructor allocates
    Student(const Student& o)                                   // copy ctor: DEEP copy
        : Person(o), regNo(o.regNo), home(new Address(*o.home)) {}
    Student& operator=(const Student&) = delete;                // (rule of three/five)
    ~Student() { delete home; }                                 // destructor releases
    void print() const { std::cout << regNo << ' ' << name << " (" << age << ") " << home->str() << '\n'; }
};
int main() {
    Student s("Kavya", 19, 192311001, "Salem", 636001);
    Student t = s;           // deep copy, no double delete
    s.print(); t.print();
}

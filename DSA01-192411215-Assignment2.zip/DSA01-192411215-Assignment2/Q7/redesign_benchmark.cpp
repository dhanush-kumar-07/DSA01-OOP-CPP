// Q7 - Diagnose, Redesign, Validate  (chosen program: Q4 SavingsAccount mini-statement)
// ORIGINAL : fixed array, shift all elements left when full  -> O(N) per transaction
// REDESIGN : same array + 'start' index (circular buffer)    -> O(1) per transaction
//   g++ -std=c++17 -O2 redesign_benchmark.cpp -o q7
#include <iostream>
#include <chrono>
#include <iomanip>

struct Transaction { char type; double amount; };

template <int N>
class ShiftHistory {                       // ORIGINAL design
    Transaction t[N]; int count = 0;
public:
    void add(char type, double amount) {
        if (count == N) { for (int i = 1; i < N; ++i) t[i - 1] = t[i]; --count; }
        t[count++] = {type, amount};
    }
    double newestAmount() const { return t[count - 1].amount; }
    double oldestAmount() const { return t[0].amount; }
};

template <int N>
class CircularHistory {                    // REDESIGN
    Transaction t[N]; int start = 0, count = 0;
public:
    void add(char type, double amount) {
        if (count < N) { t[(start + count) % N] = {type, amount}; ++count; }
        else           { t[start] = {type, amount}; start = (start + 1) % N; }
    }
    double newestAmount() const { return t[(start + count - 1) % N].amount; }
    double oldestAmount() const { return t[start].amount; }
};

template <class H>
double timeIt(long long M, double& check) {
    H h;
    auto t0 = std::chrono::steady_clock::now();
    for (long long i = 0; i < M; ++i) h.add(i & 1 ? 'D' : 'W', double(i));
    auto t1 = std::chrono::steady_clock::now();
    check = h.newestAmount() + h.oldestAmount();           // validation + stops dead-code removal
    return std::chrono::duration<double, std::milli>(t1 - t0).count();
}

template <int N>
void compare(long long M) {
    double c1, c2;
    double a = timeIt<ShiftHistory<N>>(M, c1);
    double b = timeIt<CircularHistory<N>>(M, c2);
    std::cout << std::setw(6) << N << std::setw(12) << a << std::setw(14) << b
              << std::setw(10) << std::fixed << std::setprecision(1) << a / b << "x"
              << (c1 == c2 ? "   same result" : "   RESULT MISMATCH") << '\n';
}

int main() {
    const long long M = 200000;                            // transactions per test
    std::cout << "Records added: " << M << "  (times in ms)\n";
    std::cout << std::setw(6) << "N" << std::setw(12) << "shift" << std::setw(14) << "circular"
              << std::setw(11) << "speed-up" << '\n';
    compare<10>(M);
    compare<50>(M);
    compare<1000>(M);
    compare<5000>(M);
}

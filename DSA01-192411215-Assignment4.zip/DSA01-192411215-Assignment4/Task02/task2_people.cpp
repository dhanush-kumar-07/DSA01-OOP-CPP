// Tasks 2.1 - 2.3: University people hierarchy (hybrid inheritance with virtual base)
#include <iostream>
#include <string>
#include <utility>

class Person {                                   // common base
protected:
    std::string name; int id; std::string phone;
public:
    Person(std::string n, int i, std::string p) : name(std::move(n)), id(i), phone(std::move(p)) {}
    virtual ~Person() = default;
    virtual void show() const { std::cout << id << " " << name << " " << phone; }
};

class Student : virtual public Person {          // is-a Person (public); virtual to avoid duplicate Person
protected:
    std::string programme; double cgpa;
public:
    Student(std::string n, int i, std::string p, std::string prog, double c)
        : Person(std::move(n), i, std::move(p)), programme(std::move(prog)), cgpa(c) {}
    void show() const override { Person::show(); std::cout << " | " << programme << " CGPA " << cgpa; }
};

class Staff : virtual public Person {            // is-a Person (public)
protected:
    std::string department; double salary;
public:
    Staff(std::string n, int i, std::string p, std::string d, double s)
        : Person(std::move(n), i, std::move(p)), department(std::move(d)), salary(s) {}
    void show() const override { Person::show(); std::cout << " | " << department << " Rs." << salary; }
};

class TeachingAssistant : public Student, public Staff {   // multiple inheritance -> diamond (hybrid)
public:
    TeachingAssistant(std::string n, int i, std::string p, std::string prog, double c,
                      std::string d, double s)
        : Person(n, i, p), Student(n, i, p, prog, c), Staff(n, i, p, d, s) {}
    void show() const override {
        std::cout << name << " (TA) " << programme << " / " << department << " CGPA " << cgpa << " Rs." << salary;
    }                                            // 'name' is unambiguous: only one Person sub-object
};

class ResearchScholar : public Student {         // single/multilevel: Person <- Student <- ResearchScholar
    double fellowship;
public:
    ResearchScholar(std::string n, int i, std::string p, std::string prog, double c, double f)
        : Person(n, i, p), Student(n, i, p, prog, c), fellowship(f) {}
    void show() const override { Student::show(); std::cout << " | Fellowship Rs." << fellowship; }
};

int main() {
    Student s("Kavya", 1, "9000000001", "B.Tech", 8.9);
    Staff f("Meena", 2, "9000000002", "CSE", 80000);
    TeachingAssistant ta("Arun", 3, "9000000003", "M.Tech", 9.1, "CSE", 25000);
    ResearchScholar rs("Divya", 4, "9000000004", "PhD", 9.4, 35000);
    const Person* all[] = {&s, &f, &ta, &rs};
    for (const Person* p : all) { p->show(); std::cout << '\n'; }   // polymorphism
}

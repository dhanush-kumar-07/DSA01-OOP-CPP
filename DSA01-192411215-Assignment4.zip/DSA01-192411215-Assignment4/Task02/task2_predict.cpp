// Predict the Output (Task 2). Compile normally, then again with  -DVIRT=   (virtual removed)
#include <iostream>
#ifndef VIRT
#define VIRT virtual
#endif
struct Person { Person() { std::cout << "Person "; } };
struct Student : VIRT Person { Student() { std::cout << "Student "; } };
struct Staff : VIRT Person { Staff() { std::cout << "Staff "; } };
struct TeachingAssistant : Student, Staff {
    TeachingAssistant() { std::cout << "TA "; }
};
int main() {
    TeachingAssistant ta;
    std::cout << '\n';
}

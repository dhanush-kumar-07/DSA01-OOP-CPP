// Task 11 - Recommended design: compiled-in defaults (constexpr) + optional config file at start-up
// Run from this folder:   ./main      (reads fares.cfg; falls back to constexpr defaults if missing/invalid)
#include <chrono>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

namespace defaults {
constexpr long long BASE_PAISE[3] = {1000, 2000, 3000};
constexpr int PEAK_PERCENT = 20;
constexpr long long MIN_BALANCE = 5000;
}

class FareTable {
public:
    FareTable() : peakPercent_(defaults::PEAK_PERCENT), minBalance_(defaults::MIN_BALANCE)
    { for (int i = 0; i < 3; ++i) base_[i] = defaults::BASE_PAISE[i]; }

    bool loadFromFile(const std::string& path)
    {
        std::ifstream in(path);
        if (!in) return false;
        long long b[3], minBal; int peak; std::string line; std::stringstream data;
        while (std::getline(in, line)) if (!line.empty() && line[0] != '#') data << line << ' ';
        if (!(data >> b[0] >> b[1] >> b[2] >> peak >> minBal)) return false;
        if (b[0] <= 0 || b[1] <= 0 || b[2] <= 0 || peak < 0 || peak > 100 || minBal < 0) return false;   // validate
        for (int i = 0; i < 3; ++i) base_[i] = b[i];
        peakPercent_ = peak; minBalance_ = minBal;
        return true;
    }
    long long fare(int zone, bool peak) const { long long f = base_[zone]; return peak ? f + f * peakPercent_ / 100 : f; }
    bool canTravel(long long bal, long long f) const { return bal - f >= minBalance_; }
private:
    long long base_[3]; int peakPercent_; long long minBalance_;
};

int main()
{
    FareTable table;
    auto t0 = std::chrono::steady_clock::now();
    bool loaded = table.loadFromFile("fares.cfg");
    auto t1 = std::chrono::steady_clock::now();
    std::cout << (loaded ? "Loaded fares.cfg" : "fares.cfg not usable -> using compiled defaults")
              << " in " << std::chrono::duration<double, std::micro>(t1 - t0).count() << " microseconds\n";
    std::cout << "Fares (paise): Inner " << table.fare(0, false) << ", Middle " << table.fare(1, false)
              << ", Outer " << table.fare(2, false) << ", Outer peak " << table.fare(2, true) << '\n';
    std::cout << "Balance 10000 paise, Outer peak: " << (table.canTravel(10000, table.fare(2, true)) ? "allowed" : "denied") << '\n';

    // 3,000,000 journeys with long long paise: no overflow
    long long total = 0;
    for (long long i = 0; i < 3000000; ++i) total += table.fare(static_cast<int>(i % 3), i % 5 == 0);
    std::cout << "Network total for 3,000,000 journeys = " << total << " paise (fits in long long)\n";
}

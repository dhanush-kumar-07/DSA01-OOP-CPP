// Q1 - Hostel Fee Concession: call by value, by reference, by pointer, and return-new-fee
#include <iostream>
#include <string>

struct Student {              // "large" object to show copy cost
    std::string name;
    long long fee;
    char documents[1000];
};

void concessionByValue(long long fee, int percent) {
    fee -= fee * percent / 100;
    std::cout << "  inside by-value   : " << fee << '\n';
}
void concessionByRef(long long& fee, int percent) {
    fee -= fee * percent / 100;
    std::cout << "  inside by-reference: " << fee << '\n';
}
void concessionByPtr(long long* fee, int percent) {
    if (!fee) return;                       // pointers can be null - must check
    *fee -= *fee * percent / 100;
    std::cout << "  inside by-pointer : " << *fee << '\n';
}
long long concessionReturn(long long fee, int percent) {   // design decision: return new fee
    return fee - fee * percent / 100;
}
long long readFee(const Student& s) { return s.fee; }      // const reference: no copy, no change

int main() {
    long long f1 = 45000, f2 = 45000, f3 = 45000;

    std::cout << "Predicted stored fee -> value: 45000, reference: 40500, pointer: 40500\n\n";
    concessionByValue(f1, 10);
    std::cout << "stored fee after by-value    : " << f1 << '\n';
    concessionByRef(f2, 10);
    std::cout << "stored fee after by-reference: " << f2 << '\n';
    concessionByPtr(&f3, 10);
    std::cout << "stored fee after by-pointer  : " << f3 << "\n\n";

    // Several concessions (merit 10% then sports 15%) using the returning version
    long long fee = 45000;
    fee = concessionReturn(fee, 10);
    fee = concessionReturn(fee, 15);
    std::cout << "merit(10) then sports(15) via return value: " << fee << '\n';

    Student s{"Asha", 45000, {0}};
    std::cout << "\nsizeof(long long) = " << sizeof(long long)
              << ", sizeof(long long&) pointer-sized = " << sizeof(void*)
              << ", sizeof(Student) = " << sizeof(Student) << '\n';
    std::cout << "readFee(const Student&) = " << readFee(s) << '\n';
}

// Q6 experiments: Text vs std::string for 100,000 concatenations, and operator+ via operator+= on a copy.
#include "Text.h"
#include <chrono>
#include <string>
// alternative implementation of + (by-value first parameter, then +=)
Text plus_alt(Text a, const Text& b) { a += b; return a; }

int main() {
    const int N = 100000;
    using clk = std::chrono::steady_clock;
    auto ms = [](clk::time_point a, clk::time_point b) { return std::chrono::duration<double, std::milli>(b - a).count(); };

    Text t1("Hello, "), t2("world!");
    std::string s1("Hello, "), s2("world!");
    std::size_t sum = 0;

    auto a = clk::now();
    for (int i = 0; i < N; ++i) { Text r = t1 + t2; sum += r.length(); }
    auto b = clk::now();
    for (int i = 0; i < N; ++i) { Text r = plus_alt(t1, t2); sum += r.length(); }
    auto c = clk::now();
    for (int i = 0; i < N; ++i) { std::string r = s1 + s2; sum += r.size(); }
    auto d = clk::now();

    std::cout << "Text  operator+ (classic)   : " << ms(a, b) << " ms\n";
    std::cout << "Text  plus_alt  (a += b)    : " << ms(b, c) << " ms\n";
    std::cout << "std::string operator+       : " << ms(c, d) << " ms\n";
    std::cout << "(checksum " << sum << ")\n";

    Text x("a"), y("b"), z("c");
    Text::copies = 0; Text r1 = x + y + z;
    std::cout << "copies for classic a+b+c : " << Text::copies << '\n';
    Text::copies = 0; Text r2 = plus_alt(plus_alt(x, y), z);
    std::cout << "copies for alt     a+b+c : " << Text::copies << '\n';
}

// Text.h - simple string class with dynamic memory (Rule of Three + operators)
#pragma once
#include <cstring>
#include <iostream>

class Text {
    std::size_t len;     // declared BEFORE data because data's initialiser uses len
    char* data;
public:
    static inline int copies = 0;          // counts copy constructions (C++17)

    Text(const char* s = "") : len(std::strlen(s)), data(new char[len + 1]) {
        std::memcpy(data, s, len + 1);
    }
    Text(const Text& o) : len(o.len), data(new char[o.len + 1]) {      // deep copy
        std::memcpy(data, o.data, len + 1);
        ++copies;
    }
    Text& operator=(const Text& o) {
        if (this != &o) {                                              // self-assignment guard
            char* fresh = new char[o.len + 1];
            std::memcpy(fresh, o.data, o.len + 1);
            delete[] data;
            data = fresh; len = o.len;
        }
        return *this;
    }
    ~Text() { delete[] data; }

    std::size_t length() const { return len; }
    const char* c_str() const { return data; }

    Text& operator+=(const Text& o) {
        char* fresh = new char[len + o.len + 1];
        std::memcpy(fresh, data, len);
        std::memcpy(fresh + len, o.data, o.len + 1);
        delete[] data;
        data = fresh; len += o.len;
        return *this;
    }

    // classic version: builds a new Text
    friend Text operator+(const Text& a, const Text& b) {
        char* buf = new char[a.len + b.len + 1];
        std::memcpy(buf, a.data, a.len);
        std::memcpy(buf + a.len, b.data, b.len + 1);
        Text r(buf);          // copies the characters once more
        delete[] buf;
        return r;
    }
    friend bool operator==(const Text& a, const Text& b) { return a.len == b.len && std::strcmp(a.data, b.data) == 0; }
    friend bool operator!=(const Text& a, const Text& b) { return !(a == b); }
    friend std::ostream& operator<<(std::ostream& os, const Text& t) { return os << t.data; }
};

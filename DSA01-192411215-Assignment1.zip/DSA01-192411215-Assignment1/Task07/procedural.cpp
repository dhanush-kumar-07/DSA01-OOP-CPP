// Task 7 - PROCEDURAL version: global variables + free functions
#include <iostream>

long long balance = 10000;                 // global: any function can change it
const long long MIN_BALANCE = 5000;

long long fare(int zone, bool peak)
{
    long long base = (zone == 0) ? 1000 : (zone == 1) ? 2000 : 3000;
    return peak ? base + base * 20 / 100 : base;
}
bool canTravel(long long f) { return balance - f >= MIN_BALANCE; }
void travel(int zone, bool peak)
{
    long long f = fare(zone, peak);
    if (canTravel(f)) { balance -= f; std::cout << "paid " << f << ", balance " << balance << '\n'; }
    else std::cout << "denied, balance " << balance << '\n';
}

int main()
{
    travel(0, false);
    travel(2, true);
    travel(1, false);
    balance -= 9999;                        // nothing stops this: balance is now negative!
    std::cout << "after careless code: balance " << balance << " paise (rule broken)\n";
}

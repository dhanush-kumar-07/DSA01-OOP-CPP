// Q3 - Alternative: one Parcel structure with optional fields + a function template
#include <iostream>
#include <iomanip>
#include <type_traits>

struct Parcel {
    double kg = 0;
    bool express = false;
    bool insured = false;
    bool fragile = false;      // NEW option: only this struct and charge() change
};

double charge(const Parcel& p) {
    double base = 40 + 20 * p.kg, total = base;
    if (p.express) total += 30;
    if (p.insured) total += 0.02 * base;
    if (p.fragile) total += 15;
    return total;
}

// one template replaces the int/double overloads
template <typename W>
double chargeT(W weight, bool express = false, bool insured = false) {
    double kg = std::is_integral<W>::value ? weight / 1000.0 : static_cast<double>(weight);
    Parcel p; p.kg = kg; p.express = express; p.insured = insured;
    return charge(p);
}

int main() {
    std::cout << std::fixed << std::setprecision(2);
    Parcel p; p.kg = 3.0; p.express = true; p.fragile = true;
    std::cout << "Parcel with options : " << charge(p) << '\n';
    std::cout << "chargeT(2500) grams : " << chargeT(2500) << '\n';
    std::cout << "chargeT(2.5)  kg    : " << chargeT(2.5) << '\n';
    std::cout << "chargeT(2.5f,true)  : " << chargeT(2.5f, true) << '\n';
}

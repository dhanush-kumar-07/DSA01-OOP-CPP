// Q2 - Alternative: highest mark returned as index (int) or pointer (int*)
#include <iostream>
#include <vector>

int highestIndex(const int m[], int n) {
    int idx = 0;
    for (int i = 1; i < n; ++i) if (m[i] > m[idx]) idx = i;
    return idx;
}
int* highestPtr(int m[], int n) {
    int* p = &m[0];
    for (int i = 1; i < n; ++i) if (m[i] > *p) p = &m[i];
    return p;
}
int& highestRef(int m[], int n) { return *highestPtr(m, n); }

int main() {
    int marks[] = {72, 88, 65, 91, 79};
    marks[highestIndex(marks, 5)] += 2;      // index version: caller writes marks[...]
    *highestPtr(marks, 5) += 2;              // pointer version: caller must dereference
    highestRef(marks, 5) += 2;               // reference version: cleanest call
    for (int x : marks) std::cout << x << ' ';
    std::cout << "\n(91 + 2 + 2 + 2 = 97 expected)\n";

    // With a growing vector the INDEX stays valid; the pointer/reference may dangle.
    std::vector<int> v(marks, marks + 5);
    int idx = highestIndex(v.data(), (int)v.size());
    v.insert(v.end(), 1000, 0);              // force reallocation
    std::cout << "index still valid after growth: v[" << idx << "] = " << v[idx] << '\n';
}

// Task 6 Alternative: single Vehicle class with type code and switch in charge()
#include <iostream>
#include <string>
enum class Kind { Bicycle, TwoWheeler, Car, ElectricCar };
struct Vehicle {
    Kind kind; std::string reg; double rate;
    double level = 0; int seats = 0; double battery = 0;   // unused for some kinds
    double charge(int days, int late, double used) const {
        double base = days * rate + late * rate * 1.5;
        switch (kind) {
            case Kind::Bicycle:     return base;
            case Kind::TwoWheeler:
            case Kind::Car:         return base + used * 100.0;
            case Kind::ElectricCar: return base + used * 12.0;
        }
        return base;
    }
};
int main() {
    Vehicle ev{Kind::ElectricCar, "TN03-EV", 2000, 90, 5, 40};
    std::cout << ev.charge(2, 0, 25) << "\nsizeof(Vehicle)=" << sizeof(Vehicle) << " for every kind (even a bicycle)\n";
    // A new type (ElectricBus) => edit enum + EVERY switch + add fields to this one class.
}

// Q6 - Correctness check: same time twice, either side of noon, midnight to end of day
#include <iostream>
#include <cstdlib>
class Time {
    int h, m;
public:
    Time(int hh, int mm) : h(hh), m(mm) {}
    friend int minutesBetween(const Time& a, const Time& b);
    friend bool earlier(const Time& a, const Time& b);
};
int minutesBetween(const Time& a, const Time& b) { return std::abs((a.h * 60 + a.m) - (b.h * 60 + b.m)); }
bool earlier(const Time& a, const Time& b)       { return (a.h * 60 + a.m) < (b.h * 60 + b.m); }

static int failures = 0;
#define CHECK(expr, expected) do { auto got = (expr); \
    bool ok = (got == (expected)); if (!ok) ++failures; \
    std::cout << (ok ? "PASS  " : "FAIL  ") << #expr << " -> " << got << " (expected " << (expected) << ")\n"; } while (0)

int main() {
    Time t1015(10, 15), t1015b(10, 15), t1150(11, 50), t1210(12, 10), t0900(9, 45), t1310(13, 10), t0000(0, 0), t2359(23, 59);
    CHECK(minutesBetween(t1015, t1015b), 0);          // same time twice
    CHECK(earlier(t1015, t1015b), false);             // not strictly earlier
    CHECK(minutesBetween(t1150, t1210), 20);          // across noon (11:50 -> 12:10)
    CHECK(minutesBetween(t1210, t1150), 20);          // symmetric
    CHECK(earlier(t1150, t1210), true);
    CHECK(earlier(t1210, t1150), false);
    CHECK(minutesBetween(t0900, t1310), 205);         // hand check: 585 and 790 -> 205
    CHECK(minutesBetween(t0000, t2359), 1439);
    std::cout << (failures == 0 ? "\nAll tests passed\n" : "\nSome tests FAILED\n");
}

#!/usr/bin/env bash
# Run once inside the repo folder; makes one commit per task (progressive history)
git init -q 2>/dev/null; git branch -M main
git add README.md .gitignore run_all.sh && git commit -m "Add README and run script"
for t in 01 02 03 04 05 06; do git add Task$t && git commit -m "Task$t: source, outputs"; sleep 1; done
echo "Now: git remote add origin https://github.com/<user>/DSA01-192411215-Assignment4.git && git push -u origin main"

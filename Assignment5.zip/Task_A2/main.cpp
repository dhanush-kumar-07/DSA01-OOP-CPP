// ===== TASK A2 - Runtime binding, vtables, virtual destructor (run this ONE file) =====
// Build:  g++ -std=c++17 -Wall -Wextra -fsanitize=address -g main.cpp -o a2 && ./a2
// Then:   g++ ... -DVDTOR= main.cpp -o a2b && ./a2b      (removes 'virtual' from ~Bill)
// PART 1 is the Predict-the-Output program: write your prediction BEFORE running!
#include <iostream>
#include <memory>
#include <stdexcept>

#ifndef VDTOR
#define VDTOR virtual
#endif

// ---------------- PART 1 : Predict the output ----------------
namespace predict {
struct Bill {
    VDTOR ~Bill() { std::cout << "~Bill "; }
    virtual double total() const = 0;
    void show() const { std::cout << total() << ' '; }
};
struct OPBill : Bill {
    ~OPBill() { std::cout << "~OPBill "; }     // 'override' omitted so -DVDTOR= still compiles
    double total() const override { return 500; }
};
void run()
{
    Bill* b = new OPBill;
    b->show();
    delete b;
    std::cout << '\n';
}
}

// ---------------- PART 2 : early vs late binding ----------------
namespace binding {
struct Base {
    virtual ~Base() = default;
    double early() const { return 1; }            // non-virtual: bound at COMPILE time by pointer type
    virtual double late() const { return 1; }     // virtual: bound at RUN time by object type (vtable)
};
struct Derived : Base {
    double early() const { return 2; }
    double late() const override { return 2; }
};
void run()
{
    Base* p = new Derived;
    std::cout << "early (non-virtual) via Base*: " << p->early() << "   late (virtual) via Base*: " << p->late() << '\n';
    delete p;
}
}

// ---------------- PART 3 : alternative = dynamic_cast chain ----------------
namespace alt {
struct Bill { virtual ~Bill() = default; };       // one virtual only so dynamic_cast works
struct OP : Bill { double c = 500, t = 1200; };
struct IP : Bill { double d = 3, r = 2500, x = 43000; };
double total(const Bill* b)
{
    if (auto p = dynamic_cast<const OP*>(b)) return p->c + p->t;           // up to k casts per bill
    if (auto p = dynamic_cast<const IP*>(b)) return p->d * p->r + p->x;
    throw std::logic_error("unknown bill type");
}
struct Plain { double a; };                        // no virtual => no vptr
struct Poly { virtual ~Poly() = default; double a; };
void run()
{
    std::unique_ptr<Bill> a = std::make_unique<OP>(), b = std::make_unique<IP>();
    std::cout << "dynamic_cast totals: " << total(a.get()) << ", " << total(b.get()) << '\n';
    std::cout << "sizeof(Plain)=" << sizeof(Plain) << "  sizeof(Poly)=" << sizeof(Poly)
              << "  -> one vtable pointer (" << sizeof(void*) << " bytes) per object\n";
}
}

int main()
{
    std::cout << "=== PART 1 (predict) ===\n";
    predict::run();
    std::cout << "=== PART 2 (early vs late binding) ===\n";
    binding::run();
    std::cout << "=== PART 3 (dynamic_cast alternative) ===\n";
    alt::run();
}

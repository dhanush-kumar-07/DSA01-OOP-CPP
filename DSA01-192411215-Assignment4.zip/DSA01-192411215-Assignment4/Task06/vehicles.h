// Task 6 - Vehicle rental fleet: class hierarchy (existing classes - never edited when new types are added)
#pragma once
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>

class ServiceDate {                                  // member class (has-a)
    int d_, m_, y_;
public:
    ServiceDate(int d, int m, int y) : d_(d), m_(m), y_(y) {}
    std::string str() const { return std::to_string(d_) + "/" + std::to_string(m_) + "/" + std::to_string(y_); }
};

class Vehicle {                                      // ABSTRACT base class
protected:
    std::string reg_;
    double dailyRate_;
    bool rented_ = false;
    int bookedDays_ = 0;
    static constexpr double LATE_FACTOR = 1.5;       // late days cost 1.5 x daily rate
    double base(int lateDays) const { return bookedDays_ * dailyRate_ + lateDays * dailyRate_ * LATE_FACTOR; }
public:
    Vehicle(std::string reg, double rate) : reg_(std::move(reg)), dailyRate_(rate) {}
    virtual ~Vehicle() = default;
    virtual double charge(int lateDays, double used) const = 0;   // PURE virtual: each type differs
    virtual std::string type() const = 0;
    virtual void describe() const {
        std::cout << std::left << std::setw(12) << type() << std::setw(10) << reg_
                  << "rate/day " << dailyRate_;
    }
    const std::string& regNo() const { return reg_; }
    bool isRented() const { return rented_; }
    void rent(int days) { rented_ = true; bookedDays_ = days; }
    void giveBack() { rented_ = false; }
    int booked() const { return bookedDays_; }
};

class Bicycle : public Vehicle {
public:
    using Vehicle::Vehicle;
    double charge(int lateDays, double) const override { return base(lateDays); }
    std::string type() const override { return "Bicycle"; }
};

class MotorVehicle : public Vehicle {                // still abstract: type() not defined
protected:
    double level_;                                   // fuel/charge level (%)
    ServiceDate service_;                            // member class
    static constexpr double FUEL_RATE = 100.0;       // per litre
public:
    MotorVehicle(std::string reg, double rate, double level, ServiceDate s)
        : Vehicle(std::move(reg), rate), level_(level), service_(s) {}
    double charge(int lateDays, double litres) const override { return base(lateDays) + litres * FUEL_RATE; }
    void describe() const override {
        Vehicle::describe();
        std::cout << " level " << level_ << "% service due " << service_.str();
    }
};

class TwoWheeler : public MotorVehicle {
public:
    using MotorVehicle::MotorVehicle;
    std::string type() const override { return "TwoWheeler"; }
};

class Car : public MotorVehicle {
protected:
    int seats_;
public:
    Car(std::string reg, double rate, double level, ServiceDate s, int seats)
        : MotorVehicle(std::move(reg), rate, level, s), seats_(seats) {}
    std::string type() const override { return "Car"; }
    void describe() const override { MotorVehicle::describe(); std::cout << " seats " << seats_; }
};

class ElectricCar : public Car {
protected:
    double batteryKWh_;
    static constexpr double KWH_RATE = 12.0;         // per kWh instead of per litre
public:
    ElectricCar(std::string reg, double rate, double level, ServiceDate s, int seats, double kwh)
        : Car(std::move(reg), rate, level, s, seats), batteryKWh_(kwh) {}
    double charge(int lateDays, double kwhUsed) const override { return base(lateDays) + kwhUsed * KWH_RATE; }
    std::string type() const override { return "ElectricCar"; }
    void describe() const override { Car::describe(); std::cout << " battery " << batteryKWh_ << "kWh"; }
};

class Fleet {                                        // stores an ARRAY of base-class pointers
    static constexpr int MAX = 20;
    Vehicle* v_[MAX] = {};
    int n_ = 0;
public:
    Fleet() = default;
    Fleet(const Fleet&) = delete;
    Fleet& operator=(const Fleet&) = delete;
    ~Fleet() { for (int i = 0; i < n_; ++i) delete v_[i]; }       // virtual dtor makes this correct
    bool add(Vehicle* p) { if (n_ < MAX) { v_[n_++] = p; return true; } delete p; return false; }
    Vehicle* find(const std::string& reg) const {
        for (int i = 0; i < n_; ++i) if (v_[i]->regNo() == reg) return v_[i];
        return nullptr;
    }
    bool rent(const std::string& reg, int days) {
        Vehicle* p = find(reg);
        if (!p || p->isRented()) return false;
        p->rent(days); return true;
    }
    double giveBack(const std::string& reg, int actualDays, double used) {     // returns bill, -1 on error
        Vehicle* p = find(reg);
        if (!p || !p->isRented()) return -1;
        int late = actualDays > p->booked() ? actualDays - p->booked() : 0;
        double bill = p->charge(late, used);                                    // dynamic dispatch
        p->giveBack();
        return bill;
    }
    void list() const {
        for (int i = 0; i < n_; ++i) { v_[i]->describe(); std::cout << (v_[i]->isRented() ? "  [RENTED]" : "  [available]") << '\n'; }
    }
};

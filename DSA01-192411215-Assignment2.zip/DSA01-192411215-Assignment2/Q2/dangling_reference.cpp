// Q2 - Returning a reference to a LOCAL variable (undefined behaviour!)
// Compile with:  g++ -std=c++17 -Wall -Wextra dangling_reference.cpp -o dangling
// Expected compiler warning: "reference to local variable 'x' returned [-Wreturn-local-addr]"
// Running it may print garbage, 50, or crash - all are allowed by the standard (UB).
#include <iostream>

int& badReference() {
    int x = 50;      // lives only while the function runs
    return x;        // WARNING: returns reference to a destroyed object
}

int main() {
    std::cout << "Calling badReference() - this is undefined behaviour...\n";
    int& r = badReference();
    std::cout << "value through dangling reference: " << r << '\n';
}

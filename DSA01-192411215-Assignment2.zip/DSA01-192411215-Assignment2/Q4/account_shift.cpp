// Q4 - SavingsAccount mini-statement, fixed array of 10, SHIFT on the 11th transaction
#include <iostream>
#include <iomanip>

struct Transaction {
    char   type;     // 'D' deposit, 'W' withdrawal
    double amount;
};

class SavingsAccount {
    static const int MAX = 10;
    int         accNo;
    double      balance;
    Transaction last[MAX];     // private: outsiders must not corrupt history or count
    int         count;

    void record(char type, double amount);            // defined outside
public:
    SavingsAccount(int no, double opening) : accNo(no), balance(opening), count(0) {}

    // defined INSIDE the class
    void deposit(double amount) {
        if (amount <= 0) return;
        balance += amount;
        record('D', amount);
    }
    bool withdraw(double amount);                      // defined outside
    void miniStatement() const;                        // defined outside
    double getBalance() const { return balance; }
};

void SavingsAccount::record(char type, double amount) {
    if (count == MAX) {                                // full: shift left, drop oldest  -> O(MAX)
        for (int i = 1; i < MAX; ++i) last[i - 1] = last[i];
        --count;
    }
    last[count++] = {type, amount};
}

bool SavingsAccount::withdraw(double amount) {
    if (amount <= 0 || amount > balance) return false;
    balance -= amount;
    record('W', amount);
    return true;
}

void SavingsAccount::miniStatement() const {
    std::cout << "---- Mini statement, A/c " << accNo << " ----\n";
    for (int i = 0; i < count; ++i)
        std::cout << std::setw(2) << i + 1 << ". " << (last[i].type == 'D' ? "Deposit   " : "Withdrawal")
                  << std::setw(10) << std::fixed << std::setprecision(2) << last[i].amount << '\n';
    std::cout << "Balance: " << balance << "\n\n";
}

int main() {
    SavingsAccount acc(1001, 5000);
    for (int i = 1; i <= 12; ++i) {                    // 12 transactions: first 2 get discarded
        if (i % 3 == 0) acc.withdraw(100.0 * i);
        else            acc.deposit(250.0 * i);
    }
    acc.miniStatement();
    std::cout << "Overdraw attempt (should fail): " << std::boolalpha << acc.withdraw(1e9) << '\n';
}

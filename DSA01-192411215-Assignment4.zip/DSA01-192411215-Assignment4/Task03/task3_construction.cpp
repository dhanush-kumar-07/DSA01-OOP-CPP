// Tasks 3.1 - 3.3: derived-class constructors, member classes, order of construction/destruction
#include <iostream>
#include <string>
#include <utility>

class Address {                                   // member class of Person
    std::string city;
public:
    explicit Address(std::string c) : city(std::move(c)) { std::cout << "  Address(" << city << ") built\n"; }
    ~Address() { std::cout << "  Address(" << city << ") destroyed\n"; }
};
class Course {                                    // member class of Student
    std::string title;
public:
    explicit Course(std::string t) : title(std::move(t)) { std::cout << "  Course(" << title << ") built\n"; }
    ~Course() { std::cout << "  Course(" << title << ") destroyed\n"; }
};

class Person {
protected:
    std::string name; int id; Address addr;
public:
    Person(std::string n, int i, const std::string& city) : name(std::move(n)), id(i), addr(city)
    { std::cout << "  Person(" << name << ") built\n"; }
    virtual ~Person() { std::cout << "  Person(" << name << ") destroyed\n"; }
};
class Student : virtual public Person {
protected:
    std::string programme; Course course;
public:
    Student(std::string n, int i, const std::string& city, std::string prog, const std::string& crs)
        : Person(std::move(n), i, city), programme(std::move(prog)), course(crs)
    { std::cout << "  Student built\n"; }
    ~Student() override { std::cout << "  Student destroyed\n"; }
};
class Staff : virtual public Person {
protected:
    std::string dept;
public:
    Staff(std::string n, int i, const std::string& city, std::string d)
        : Person(std::move(n), i, city), dept(std::move(d)) { std::cout << "  Staff built\n"; }
    ~Staff() override { std::cout << "  Staff destroyed\n"; }
};
class TeachingAssistant : public Student, public Staff {
public:
    // Most-derived class MUST call the virtual base constructor itself, because the
    // Person sub-object is built once, by the most derived class, before Student/Staff.
    TeachingAssistant(std::string n, int i, const std::string& city, std::string prog,
                      const std::string& crs, std::string d)
        : Person(n, i, city), Student(n, i, city, prog, crs), Staff(n, i, city, d)
    { std::cout << "  TeachingAssistant built\n"; }
    ~TeachingAssistant() override { std::cout << "  TeachingAssistant destroyed\n"; }
};

int main() {
    std::cout << "--- Student ---\n";           { Student s("Kavya", 1, "Salem", "B.Tech", "C++"); }
    std::cout << "--- Staff ---\n";             { Staff f("Meena", 2, "Chennai", "CSE"); }
    std::cout << "--- TeachingAssistant ---\n"; { TeachingAssistant t("Arun", 3, "Madurai", "M.Tech", "AI", "CSE"); }
}

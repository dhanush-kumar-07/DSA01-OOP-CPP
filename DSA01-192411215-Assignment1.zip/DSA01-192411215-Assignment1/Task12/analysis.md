# Task 12 - Impact analysis and decision (use as notes for your report)

## A. Impact analysis
| Item | Affected? | Change |
|---|---|---|
| `enum class Zone` | Yes | add `Airport` (+ `COUNT`) |
| `BASE_PAISE[]` constants | Yes | add 6000 |
| `switch (z)` in `fare()` | Yes | needs a new `case Zone::Airport` (and every other switch on Zone) |
| `isPeak()` expression | No | unchanged |
| surcharge expression | Yes | must NOT apply on weekends |
| `SmartCard` class | Partly | needs a pass; balance logic unchanged |
| new constants | Yes | `WEEKEND_DISCOUNT_PERCENT = 10` |
| new class | Yes | `Pass` (two zones) |

## B. Evaluation of the original design (worked examples)
* Airport weekday peak: original `switch` has no Airport case -> returns 0 (free ride!) via `default`. Silent bug.
* Airport weekend peak: original code adds 20% whenever `peak` is true -> 7200 instead of 5400.
* Pass holder in Inner: original `deduct()` always charges -> pass is ignored.
* SmartCard rule (balance >= Rs 50) still correct, so the CLASS can be retained; the fare logic must be MODIFIED.

## C. Decision: MODIFY (not full redesign)
Table indexed by zone, a separate time/discount rule function, and a `Pass` class. `static_assert` guarantees one fare per zone.

## D. Defence
`main.cpp` runs 11 tests (all PASS): new Airport fare, weekend no-surcharge, pass coverage, and the unchanged balance rule.
Cost: O(1) time and O(zones) space; adding a fifth zone = one enum value + one table row.

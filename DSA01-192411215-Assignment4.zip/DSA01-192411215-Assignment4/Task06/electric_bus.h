// NEW vehicle type added later - vehicles.h is NOT modified
#pragma once
#include "vehicles.h"
class ElectricBus : public ElectricCar {
    int passengers_;
    static constexpr double PERMIT_PER_DAY = 500.0;
public:
    ElectricBus(std::string reg, double rate, double level, ServiceDate s, int seats, double kwh, int passengers)
        : ElectricCar(std::move(reg), rate, level, s, seats, kwh), passengers_(passengers) {}
    double charge(int lateDays, double kwhUsed) const override {
        return ElectricCar::charge(lateDays, kwhUsed) + booked() * PERMIT_PER_DAY;   // permit surcharge
    }
    std::string type() const override { return "ElectricBus"; }
    void describe() const override { ElectricCar::describe(); std::cout << " passengers " << passengers_; }
};

# DSA01-192411215-Assignment2 (CO2)

- **Name:** Dhanush Kumar R
- **Register number:** 192411215
- **Compiler:** g++ (version: ______ , run `g++ --version`)
- **Compile command:** `g++ -std=c++17 -Wall -Wextra file.cpp -o file` (benchmarks also with `-O0` / `-O2`)

## How to run
```
g++ -std=c++17 -Wall -Wextra Q1/three_ways.cpp -o q1 && ./q1      (Windows: q1.exe)
```
Or everything at once: `./run_all.sh` (Linux/Git-Bash) or `run_all.bat` (Windows).

## Tasks
| Folder | Files | Result (fill in) |
|---|---|---|
| Q1 | three_ways, predict_output, complete_code | |
| Q2 | marks_register, dangling_reference, vector_invalidation, alt_index_pointer | |
| Q3 | ambiguous_error (fails on purpose), courier, alt_parcel_template | |
| Q4 | account_shift, account_circular, account_deque | |
| Q5 | predict_output, complete_code, tickets_in_function, alt_ticket_office | |
| Q6 | complete_code, correctness_tests, inline_benchmark | |
| Q7 | redesign_benchmark, REPORT_NOTES.md | |

Put output screenshots in each Q folder.

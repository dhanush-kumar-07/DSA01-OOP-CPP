// Task 9 - Complete fare logic + table-driven tests (expected vs actual)
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>

enum class Zone { Inner, Middle, Outer };
enum class Rider { Regular, Student, Senior };

constexpr long long BASE_PAISE[] = {1000, 2000, 3000};
constexpr int PEAK_PERCENT = 20;
constexpr int CONCESSION_PERCENT = 50;                 // assumption: students and seniors pay half
constexpr long long MIN_BALANCE_PAISE = 5000;

class SmartCard {
public:
    explicit SmartCard(long long p) : balance_(p) {}
    bool canTravel(long long f) const { return f >= 0 && balance_ - f >= MIN_BALANCE_PAISE; }
    bool deduct(long long f) { if (!canTravel(f)) return false; balance_ -= f; return true; }
    bool recharge(long long p) { if (p <= 0) return false; balance_ += p; return true; }
    long long balance() const { return balance_; }
private:
    long long balance_;
};

constexpr bool isPeak(int hour) { return (hour >= 8 && hour < 10) || (hour >= 17 && hour < 20); }

bool parseZone(int code, Zone& z)
{
    if (code < 0 || code > 2) return false;           // unknown zone
    z = static_cast<Zone>(code);
    return true;
}
bool parseHour(const std::string& s, int& hour)       // letters typed for the hour are rejected
{
    try {
        std::size_t pos = 0;
        int v = std::stoi(s, &pos);
        if (pos != s.size() || v < 0 || v > 23) return false;
        hour = v;
        return true;
    } catch (const std::exception&) { return false; }
}
long long fare(Zone z, int hour, Rider r)
{
    long long f = BASE_PAISE[static_cast<int>(z)];
    if (isPeak(hour)) f += f * PEAK_PERCENT / 100;
    if (r != Rider::Regular) f -= f * CONCESSION_PERCENT / 100;
    return f;
}

struct Case { const char* name; int zone; const char* hour; Rider rider; long long expected; };  // -1 = must be rejected

int main()
{
    Case cases[] = {
        {"Inner off-peak",         0, "12", Rider::Regular, 1000},
        {"Middle off-peak",        1, "12", Rider::Regular, 2000},
        {"Outer off-peak",         2, "12", Rider::Regular, 3000},
        {"Inner peak morning",     0, "9",  Rider::Regular, 1200},
        {"Middle peak evening",    1, "18", Rider::Regular, 2400},
        {"Outer peak",             2, "8",  Rider::Regular, 3600},
        {"Boundary 08:00 (peak)",  2, "8",  Rider::Regular, 3600},
        {"Boundary 10:00 (off)",   2, "10", Rider::Regular, 3000},
        {"Boundary 17:00 (peak)",  2, "17", Rider::Regular, 3600},
        {"Boundary 20:00 (off)",   2, "20", Rider::Regular, 3000},
        {"Student Outer peak",     2, "9",  Rider::Student, 1800},
        {"Senior Middle off-peak", 1, "13", Rider::Senior,  1000},
        {"Invalid: unknown zone 3",3, "12", Rider::Regular, -1},
        {"Invalid: zone -1",      -1, "12", Rider::Regular, -1},
        {"Invalid: hour 'ab'",     0, "ab", Rider::Regular, -1},
        {"Invalid: hour '9x'",     0, "9x", Rider::Regular, -1},
        {"Invalid: hour 24",       0, "24", Rider::Regular, -1},
    };

    int pass = 0, total = 0;
    std::cout << std::left << std::setw(26) << "Test" << std::setw(10) << "Expected" << std::setw(10) << "Actual" << "Result\n" << std::right;
    for (const Case& c : cases) {
        Zone z; int h; long long actual;
        if (!parseZone(c.zone, z) || !parseHour(c.hour, h)) actual = -1;
        else actual = fare(z, h, c.rider);
        bool ok = (actual == c.expected);
        ++total; pass += ok;
        std::cout << std::left << std::setw(26) << c.name << std::setw(10) << c.expected << std::setw(10) << actual
                  << (ok ? "PASS" : "FAIL") << '\n' << std::right;
    }

    // balance boundary: exactly Rs 50 must remain
    struct B { const char* name; long long bal, f; bool expected; } bcases[] = {
        {"Leaves exactly Rs 50", 6000, 1000, true},
        {"Leaves Rs 49.99",      5999, 1000, false},
        {"Balance below minimum",4000, 0,    false},
    };
    for (const B& b : bcases) {
        SmartCard card(b.bal);
        bool actual = card.canTravel(b.f);
        bool ok = actual == b.expected;
        ++total; pass += ok;
        std::cout << std::left << std::setw(26) << b.name << std::setw(10) << b.expected << std::setw(10) << actual << (ok ? "PASS" : "FAIL") << '\n' << std::right;
    }
    // negative recharge
    { SmartCard card(10000); bool r = card.recharge(-500); bool ok = !r && card.balance() == 10000;
      ++total; pass += ok;
      std::cout << std::left << std::setw(26) << "Invalid: negative recharge" << std::setw(10) << 0 << std::setw(10) << r << (ok ? "PASS" : "FAIL") << '\n' << std::right; }

    // 5 journeys totalled by hand: 1000 + 2400 + 3000 + 1200 + 1000 = 8600 ; Rs 200 - Rs 86 = Rs 114
    SmartCard card(20000);
    struct J { int zone; int hour; Rider r; } js[] = {{0, 12, Rider::Regular}, {1, 8, Rider::Regular}, {2, 11, Rider::Regular},
                                                      {0, 17, Rider::Regular}, {1, 15, Rider::Student}};
    long long total5 = 0;
    for (const J& j : js) {
        long long f = fare(static_cast<Zone>(j.zone), j.hour, j.r);
        if (card.deduct(f)) total5 += f;
    }
    bool ok5 = (total5 == 8600 && card.balance() == 11400);
    ++total; pass += ok5;
    std::cout << "\n5-journey set: hand total 8600, program total " << total5 << ", balance " << card.balance() << " -> " << (ok5 ? "PASS" : "FAIL") << '\n';
    std::cout << "\nSummary: " << pass << " / " << total << " tests passed\n";
    return pass == total ? 0 : 1;
}

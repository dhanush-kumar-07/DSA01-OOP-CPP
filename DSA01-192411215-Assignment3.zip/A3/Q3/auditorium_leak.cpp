// Q3 experiment: forgotten delete. Run with -fsanitize=address -> LeakSanitizer report.
#include <iostream>
struct Event {
    int* data;
    Event() : data(new int[10]) { std::cout << "ctor\n"; }
    ~Event() { delete[] data; std::cout << "dtor\n"; }
};
int main() {
    Event* e = new Event();   // delete e; is missing -> destructor never runs, memory leaks
    (void)e;
}

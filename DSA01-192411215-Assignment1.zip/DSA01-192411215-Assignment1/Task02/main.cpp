// Task 2 - Tokens, keywords, identifiers and constants
#include <iostream>

// ---- the SINGLE place where fares and limits are defined ----
enum class Zone { Inner, Middle, Outer };
constexpr int  BASE_PAISE[] = {1000, 2000, 3000};
constexpr int  PEAK_SURCHARGE_PERCENT = 20;
constexpr long long MIN_BALANCE_PAISE = 5000;

// ---- for comparison: the old unsafe way ----
#define FARE_INNER 1000
#define DOUBLE_IT(x) x * 2            // classic macro bug: no brackets
enum OldZone { OInner, OMiddle, OOuter };  // plain enum

int main()
{
    // Tokens in this one statement:  int(keyword) fare(identifier) =(operator) 1000(constant) ;(punctuator)
    int fare = FARE_INNER;
    std::cout << "fare token demo: " << fare << '\n';

    // macro has no type/scope/checking
    std::cout << "DOUBLE_IT(1 + 2) = " << DOUBLE_IT(1 + 2) << "  (expected 6, got 5: macro text substitution)\n";
    constexpr int twice = (1 + 2) * 2;
    std::cout << "constexpr twice  = " << twice << '\n';

    // plain enum leaks into scope and converts to int silently
    OldZone oz = OOuter;
    std::cout << "plain enum OOuter == 2 ? " << (oz == 2) << "  (silent int comparison)\n";

    // enum class: scoped, no implicit int conversion
    Zone z = Zone::Outer;
    // if (z == 2) {}   // ERROR: no conversion - compile-time protection
    std::cout << "enum class needs a cast: " << static_cast<int>(z) << '\n';
    std::cout << "fare from table: " << BASE_PAISE[static_cast<int>(z)] << " paise\n";

    // constexpr is checked at compile time
    static_assert(MIN_BALANCE_PAISE == 5000, "minimum balance must be Rs 50");
    static_assert(sizeof(BASE_PAISE) / sizeof(BASE_PAISE[0]) == 3, "three zones");
    std::cout << "peak surcharge " << PEAK_SURCHARGE_PERCENT << "%, min balance " << MIN_BALANCE_PAISE << " paise\n";

    // Naming: camelCase variables, UPPER_SNAKE constants, PascalCase types. 2zone / my-var / int are illegal identifiers.
}

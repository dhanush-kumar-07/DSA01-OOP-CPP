// Q3 - Redesigned courier charge: default arguments + overloading, no ambiguity
#include <iostream>
#include <iomanip>

struct Parcel {
    double kg;
    bool express = false;
    bool insured = false;
};

// single place where the price is calculated
static double price(double kg, bool express, bool insured) {
    double base = 40 + 20 * kg;
    double total = base;
    if (express) total += 30;
    if (insured) total += 0.02 * base;
    return total;
}

// weight in grams (int)
double charge(int grams, bool express = false, bool insured = false) {
    std::cout << "[int grams ] ";
    return price(grams / 1000.0, express, insured);
}
// weight in kg (double)
double charge(double kg, bool express = false, bool insured = false) {
    std::cout << "[double kg ] ";
    return price(kg, express, insured);
}
// Parcel object
double charge(const Parcel& p) {
    std::cout << "[Parcel    ] ";
    return price(p.kg, p.express, p.insured);
}

int main() {
    std::cout << std::fixed << std::setprecision(2);
    Parcel p{3.0, true, false};

    // Prediction:
    // charge(2)           -> int exact match            -> grams version (2 g!)
    // charge(2.0f)        -> float->double PROMOTION    -> kg version (beats float->int conversion)
    // charge(2.5)         -> double exact match         -> kg version
    // charge(500, true)   -> int exact                  -> grams version, express
    // charge(1.5,true,true)-> double exact              -> kg version, express+insured
    // charge(p)           -> Parcel exact               -> Parcel version
    std::cout << "charge(2)            = " << charge(2) << '\n';
    std::cout << "charge(2.0f)         = " << charge(2.0f) << '\n';
    std::cout << "charge(2.5)          = " << charge(2.5) << '\n';
    std::cout << "charge(500, true)    = " << charge(500, true) << '\n';
    std::cout << "charge(1.5,true,true)= " << charge(1.5, true, true) << '\n';
    std::cout << "charge(p)            = " << charge(p) << '\n';

    // charge(2L);   // would be AMBIGUOUS: long->int and long->double are both conversions
}

// Q7 - Complex class and AC impedance calculator (series / parallel RLC)
#include <cmath>
#include <complex>
#include <iomanip>
#include <iostream>
#include <stdexcept>

class Complex {
    double re, im;
public:
    // default (0+0j), from real part (R + 0j), from real and imaginary parts
    Complex() : re(0), im(0) {}
    Complex(double r) : re(r), im(0) {}                  // implicit on purpose: allows 2.0 + z
    Complex(double r, double i) : re(r), im(i) {}

    double real() const { return re; }
    double imag() const { return im; }
    double magnitude() const { return std::sqrt(re * re + im * im); }

    // (a+bj)+(c+dj) = (a+c) + (b+d)j
    friend Complex operator+(const Complex& x, const Complex& y) { return Complex(x.re + y.re, x.im + y.im); }
    // (a+bj)-(c+dj) = (a-c) + (b-d)j
    friend Complex operator-(const Complex& x, const Complex& y) { return Complex(x.re - y.re, x.im - y.im); }
    // (a+bj)(c+dj) = (ac-bd) + (ad+bc)j
    friend Complex operator*(const Complex& x, const Complex& y) {
        return Complex(x.re * y.re - x.im * y.im, x.re * y.im + x.im * y.re);
    }
    // (a+bj)/(c+dj) = ((ac+bd) + (bc-ad)j) / (c^2+d^2)   -> division by zero impedance is rejected
    friend Complex operator/(const Complex& x, const Complex& y) {
        double den = y.re * y.re + y.im * y.im;
        if (den == 0.0) throw std::domain_error("Division by zero impedance");
        return Complex((x.re * y.re + x.im * y.im) / den, (x.im * y.re - x.re * y.im) / den);
    }
    // equality with a tolerance (floating-point)
    friend bool operator==(const Complex& x, const Complex& y) {
        return std::fabs(x.re - y.re) < 1e-9 && std::fabs(x.im - y.im) < 1e-9;
    }
    friend std::ostream& operator<<(std::ostream& os, const Complex& z) {
        os << std::fixed << std::setprecision(2) << z.re << (z.im < 0 ? " - j" : " + j") << std::fabs(z.im);
        return os;
    }
};

Complex parallel(const Complex& z1, const Complex& z2) { return (z1 * z2) / (z1 + z2); }

int main() {
    const double R = 100.0, L = 0.2, C = 10e-6, w = 1000.0;     // ohm, henry, farad, rad/s
    Complex ZR(R), ZL(0, w * L), ZC(0, -1.0 / (w * C));          // 100+j0, 0+j200, 0-j100

    std::cout << "ZR = " << ZR << "\nZL = " << ZL << "\nZC = " << ZC << "\n\n";

    Complex series = ZR + ZL + ZC;
    std::cout << "Series RLC   : " << series << "   |Z| = " << series.magnitude() << " ohm\n";
    std::cout << "  hand check : 100 + j(200-100) = 100 + j100, |Z| = 141.42\n\n";

    Complex par = parallel(parallel(ZR, ZL), ZC);
    std::cout << "Parallel RLC : " << par << "   |Z| = " << par.magnitude() << " ohm\n";
    std::cout << "  hand check : R||L = 80 + j40 ; (80+j40)||(-j100) = 80 - j40, |Z| = 89.44\n\n";

    std::cout << std::boolalpha << "series == Complex(100,100): " << (series == Complex(100, 100)) << '\n';
    std::cout << "2.0 + ZL = " << (2.0 + ZL) << "  (implicit conversion from double)\n\n";

    std::cout << "Division by a zero impedance:\n";
    try {
        Complex bad = ZR / Complex(0, 0);
        std::cout << bad << '\n';
    } catch (const std::domain_error& e) {
        std::cout << "  caught: " << e.what() << '\n';
    }

    // comparison with std::complex<double>
    std::complex<double> sR(R, 0), sL(0, w * L), sC(0, -1.0 / (w * C));
    std::complex<double> sp = (sR * sL / (sR + sL)) * sC / ((sR * sL / (sR + sL)) + sC);
    std::cout << "\nstd::complex parallel: " << sp.real() << (sp.imag() < 0 ? " - j" : " + j") << std::fabs(sp.imag())
              << "   |Z| = " << std::abs(sp) << '\n';
    std::complex<double> inf = sR / std::complex<double>(0, 0);
    std::cout << "std::complex division by zero -> (" << inf.real() << ", " << inf.imag() << ")  (no exception; NaN/inf)\n";
}

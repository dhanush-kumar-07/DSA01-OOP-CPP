// Tasks 5.1 / 5.2: four ways to reach an object, this pointer, array of Cart pointers
#include <iomanip>
#include <iostream>
#include <string>
#include <utility>

class Cart {
    std::string owner;
    std::string items[10];
    double prices[10] = {};
    int n = 0;
    double discount = 0;                                   // percent
public:
    explicit Cart(std::string owner = "guest") : owner(std::move(owner)) {}
    Cart& add(const std::string& item, double price) {
        if (n < 10) { items[n] = item; prices[n] = price; ++n; }
        return *this;                                      // chaining
    }
    Cart& setDiscount(double discount) { this->discount = discount; return *this; }  // this-> separates member/param
    double total() const {
        double t = 0; for (int i = 0; i < n; ++i) t += prices[i];
        return t * (100 - discount) / 100;
    }
    const std::string& who() const { return owner; }
    const Cart* self() const { return this; }              // 'this' is a pointer to the current object
};

int main() {
    std::cout << std::fixed << std::setprecision(2);
    // (a) directly by name
    Cart a("Asha"); a.add("Rice", 60).add("Dal", 120).setDiscount(10);
    std::cout << "(a) name      : " << a.who() << " " << a.total() << '\n';
    // (b) through a pointer with ->
    Cart* p = &a; p->add("Oil", 180);
    std::cout << "(b) pointer   : " << p->total() << "  (this == &a ? " << (a.self() == &a) << ")\n";
    // (c) through a reference
    Cart& r = a; r.add("Salt", 20);
    std::cout << "(c) reference : " << r.total() << '\n';
    // (d) pointer created with new, released with delete
    Cart* d = new Cart("Dev"); d->add("Tea", 250).setDiscount(20);
    std::cout << "(d) new/delete: " << d->total() << '\n';
    delete d;

    // Task 5.2 - array of pointers, find highest total
    Cart* carts[4] = { new Cart("Asha"), new Cart("Bala"), new Cart("Chitra"), new Cart("Dev") };
    carts[0]->add("Rice", 60);
    carts[1]->add("TV", 25000).setDiscount(5);
    carts[2]->add("Soap", 40).add("Milk", 30);
    carts[3]->add("Phone", 15000);

    Cart* best = carts[0];                                 // (i) indexing
    for (int i = 1; i < 4; ++i) if (carts[i]->total() > best->total()) best = carts[i];
    std::cout << "Highest (indexing)         : " << best->who() << " " << best->total() << '\n';

    Cart** q = carts; Cart* best2 = *q;                    // (ii) pointer arithmetic
    for (Cart** e = carts + 4; q < e; ++q) if ((*q)->total() > best2->total()) best2 = *q;
    std::cout << "Highest (pointer arithmetic): " << best2->who() << " " << best2->total() << '\n';

    for (Cart* c : carts) delete c;
}

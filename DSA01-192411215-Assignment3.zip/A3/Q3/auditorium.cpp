// Q3 - Dynamic constructor / destructor (Auditorium Seat Booking)
#include <iostream>
#include <stdexcept>
#include <string>

class Event {
    std::string name;
    int rows, seatsPerRow;
    char** seats;       // 2-D map: seats[r][s] is '.' (free) or 'X' (booked)
    int booked;
public:
    // Dynamic constructor: sizes known only at run time
    Event(const std::string& n, int r, int s) : name(n), rows(r), seatsPerRow(s), seats(nullptr), booked(0) {
        if (r < 0 || s < 0) throw std::invalid_argument("negative size");
        seats = new char*[rows];
        for (int i = 0; i < rows; ++i) {
            seats[i] = new char[seatsPerRow];
            for (int j = 0; j < seatsPerRow; ++j) seats[i][j] = '.';
        }
        std::cout << "[ctor ] Event \"" << name << "\" created: " << rows << " x " << seatsPerRow << '\n';
    }
    // Destructor: no arguments, cannot be overloaded; releases every allocation
    ~Event() {
        std::cout << "[dtor ] Event \"" << name << "\" closing. Booked seats at close: " << booked
                  << " of " << rows * seatsPerRow << '\n';
        for (int i = 0; i < rows; ++i) delete[] seats[i];
        delete[] seats;
    }
    Event(const Event&) = delete;             // prevent shallow copies
    Event& operator=(const Event&) = delete;

    bool book(int r, int s) {
        if (r < 0 || r >= rows || s < 0 || s >= seatsPerRow) { std::cout << "  invalid seat\n"; return false; }
        if (seats[r][s] == 'X') { std::cout << "  seat already booked\n"; return false; }
        seats[r][s] = 'X'; ++booked; return true;
    }
    bool cancel(int r, int s) {
        if (r < 0 || r >= rows || s < 0 || s >= seatsPerRow || seats[r][s] != 'X') { std::cout << "  nothing to cancel\n"; return false; }
        seats[r][s] = '.'; --booked; return true;
    }
    void show() const {
        for (int i = 0; i < rows; ++i) { std::cout << "  "; for (int j = 0; j < seatsPerRow; ++j) std::cout << seats[i][j]; std::cout << '\n'; }
    }
    // bytes of heap used by the map: row-pointer array + all rows
    std::size_t bytes() const { return rows * sizeof(char*) + (std::size_t)rows * seatsPerRow; }
};

int main() {
    std::cout << "--- Stack object ---\n";
    Event onStack("Stack Concert", 3, 5);
    onStack.book(0, 1); onStack.book(2, 4); onStack.book(0, 1); onStack.cancel(2, 4);
    onStack.show();

    std::cout << "--- Block-scope object ---\n";
    {
        Event inBlock("Block Workshop", 2, 4);
        inBlock.book(1, 1);
        std::cout << "  leaving block...\n";
    }
    std::cout << "--- Heap object ---\n";
    Event* onHeap = new Event("Heap Seminar", 2, 3);
    onHeap->book(0, 0);
    delete onHeap;               // destructor runs here

    std::cout << "--- Zero rows ---\n";
    { Event empty("Empty Event", 0, 10); empty.book(0, 0); }

    std::cout << "--- Memory for different sizes ---\n";
    int dims[3][2] = {{10, 20}, {100, 200}, {1000, 2000}};
    for (auto& d : dims) {
        Event e("Size test", d[0], d[1]);
        std::cout << "  " << d[0] << " x " << d[1] << " -> " << e.bytes() << " bytes\n";
    }
    std::cout << "--- end of main (stack object destroyed after this line) ---\n";
}

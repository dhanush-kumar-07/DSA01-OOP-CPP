# Creates one commit per task (the assignment checks commit history). Run AFTER: git init, git remote add origin <your url>
# Usage: powershell -ExecutionPolicy Bypass -File .\commit_each_task.ps1
git add .gitignore README.md .vscode run_all.ps1 run_all.sh commit_each_task.ps1
git commit -m "Add README and helper scripts"
1..12 | ForEach-Object {
  $t = "Task{0:D2}" -f $_
  git add $t
  git add outputs\${t}_* 2>$null
  git commit -m "$t - source code and output"
}
git branch -M main
git push -u origin main

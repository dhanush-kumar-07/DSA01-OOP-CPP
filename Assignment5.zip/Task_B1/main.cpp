// ===== TASK B1 - Implement and validate polymorphic billing (run this ONE file) =====
// Build: g++ -std=c++17 -Wall -Wextra -fsanitize=address -g main.cpp -o b1 && ./b1
// Sections: (1) Complete-the-Code  (2) all bills x all payers, hand-verified (B1.1)
//           (3) template alternative (4) B1.3 / B1.4 proofs.
// For B1.3 build with  -DVT=   (total() not virtual).   For B1.4 build with  -DVD=  (destructor not virtual;
// ASan will report an error and stop the program - that is the evidence, so section 4 runs last).
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <map>
#include <memory>
#include <new>
#include <optional>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>


// ---------------- Exception hierarchy (A4.1) ----------------
class BillingError : public std::runtime_error {
public:
    using std::runtime_error::runtime_error;
};
class NegativeChargeError : public BillingError { public: using BillingError::BillingError; };
class ClaimError          : public BillingError { public: using BillingError::BillingError; };
class UnknownPackageError : public BillingError { public: using BillingError::BillingError; };
class MissingRecordError  : public BillingError { public: using BillingError::BillingError; };
// std::bad_alloc is left as the standard exception for allocation failure.

inline void requireNonNegative(double v, const char* what)
{
    if (v < 0) throw NegativeChargeError(std::string("negative ") + what);
}

inline double packagePrice(const std::string& code)
{
    static const std::map<std::string, double> table{
        {"CATARACT", 25000}, {"HERNIA", 45000}, {"APPENDIX", 38000}};
    auto it = table.find(code);
    if (it == table.end()) throw UnknownPackageError("unknown package: " + code);
    return it->second;
}

// ---------------- Patient records ----------------
class PatientRegistry {
    std::set<std::string> names;
public:
    void add(const std::string& n) { names.insert(n); }
    void require(const std::string& n) const
    {
        if (!names.count(n)) throw MissingRecordError("no patient record for " + n);
    }
};

// ---------------- Abstract Bill (A1) ----------------
class Bill {
protected:
    std::string patient;
public:
    explicit Bill(std::string p) : patient(std::move(p)) {}
    Bill(const Bill&) = delete;
    Bill& operator=(const Bill&) = delete;
    virtual ~Bill() = default;                      // virtual destructor (A2.3)

    virtual double total() const noexcept = 0;      // pure virtual
    virtual std::string type() const = 0;           // pure virtual

    const std::string& patientName() const noexcept { return patient; }
    void print() const
    {
        std::cout << type() << ' ' << patient << ": " << total() << '\n';
    }
};

class OutPatientBill : public Bill {
    double consultation, tests;
public:
    OutPatientBill(const std::string& p, double c, double t)
        : Bill(p), consultation(c), tests(t)
    {
        requireNonNegative(c, "consultation charge");
        requireNonNegative(t, "test charge");
    }
    double total() const noexcept override { return consultation + tests; }
    std::string type() const override { return "OP"; }
};

class InPatientBill : public Bill {
    int days;
    double perDay, procedures, medicines;
public:
    InPatientBill(const std::string& p, int d, double rate, double proc, double med)
        : Bill(p), days(d), perDay(rate), procedures(proc), medicines(med)
    {
        if (d < 0) throw NegativeChargeError("negative number of days");
        requireNonNegative(rate, "room rate");
        requireNonNegative(proc, "procedure charge");
        requireNonNegative(med, "medicine charge");
    }
    double total() const noexcept override { return days * perDay + procedures + medicines; }
    std::string type() const override { return "IP"; }
};

class DayCareBill : public Bill {
    double price;
public:
    DayCareBill(const std::string& p, const std::string& packageCode)
        : Bill(p), price(packagePrice(packageCode)) {}   // may throw UnknownPackageError
    double total() const noexcept override { return price; }
    std::string type() const override { return "DC"; }
};

class EmergencyBill : public Bill {
    double base, hours, ratePerHour;
public:
    EmergencyBill(const std::string& p, double b, double h, double r)
        : Bill(p), base(b), hours(h), ratePerHour(r)
    {
        requireNonNegative(b, "base charge");
        requireNonNegative(h, "hours");
        requireNonNegative(r, "hourly rate");
    }
    double total() const noexcept override { return base + hours * ratePerHour; }
    std::string type() const override { return "ER"; }
};

// ---------------- Abstract Payer (A3) ----------------
class Payer {
public:
    virtual ~Payer() = default;
    virtual double amountCovered(const Bill& b) const = 0;
    virtual std::string name() const = 0;
};

class SelfPay : public Payer {
public:
    double amountCovered(const Bill&) const override { return 0.0; }
    std::string name() const override { return "SelfPay"; }
};

class Insurance : public Payer {
    double limit, copayPct;
public:
    Insurance(double coverLimit, double copayPercent)
        : limit(coverLimit), copayPct(copayPercent)
    {
        if (coverLimit < 0 || copayPercent < 0 || copayPercent > 100)
            throw std::invalid_argument("bad insurance policy");
    }
    double amountCovered(const Bill& b) const override
    {
        double t = b.total();
        if (t > limit) throw ClaimError("claim " + std::to_string(t) + " exceeds cover " + std::to_string(limit));
        return t * (1.0 - copayPct / 100.0);
    }
    std::string name() const override { return "Insurance(" + std::to_string((int)copayPct) + "% co-pay)"; }
};

class GovernmentScheme : public Payer {
    std::map<std::string, double> rates;   // fixed package rate per bill type
public:
    static std::map<std::string, double> defaultRates()
    {
        return {{"OP", 1000}, {"IP", 30000}, {"DC", 25000}, {"ER", 5000}};
    }
    explicit GovernmentScheme(std::map<std::string, double> r = defaultRates()) : rates(std::move(r)) {}
    double amountCovered(const Bill& b) const override
    {
        auto it = rates.find(b.type());
        if (it == rates.end()) throw UnknownPackageError("no package rate for bill type " + b.type());
        return std::min(b.total(), it->second);
    }
    std::string name() const override { return "GovScheme"; }
};

struct Settlement { double total, covered, patientPays; };

inline Settlement settle(const Bill& b, const Payer& p)
{
    double c = p.amountCovered(b);          // may throw ClaimError / UnknownPackageError
    return {b.total(), c, b.total() - c};
}

inline int runCoreTests()
{
    int failures = 0;
    auto close = [](double a, double b) { return std::fabs(a - b) < 1e-6; };

    std::vector<std::unique_ptr<Bill>> bills;
    bills.push_back(std::make_unique<OutPatientBill>("Ravi", 500, 1200));
    bills.push_back(std::make_unique<InPatientBill>("Meena", 3, 2500, 40000, 3000));
    bills.push_back(std::make_unique<DayCareBill>("Arun", "CATARACT"));
    bills.push_back(std::make_unique<EmergencyBill>("Divya", 3000, 2, 1500));

    // Hand calculation:
    //  OP: 500 + 1200            = 1700
    //  IP: 3*2500 + 40000 + 3000 = 50500
    //  DC: package CATARACT      = 25000
    //  ER: 3000 + 2*1500         = 6000     -> day total 83200
    const double expTotal[] = {1700, 50500, 25000, 6000};

    std::cout << "--- Bill totals (processed through Bill*) ---\n";
    double day = 0;
    for (std::size_t i = 0; i < bills.size(); ++i) {
        bills[i]->print();
        if (!close(bills[i]->total(), expTotal[i])) { ++failures; std::cout << "  FAIL\n"; }
        day += bills[i]->total();
    }
    std::cout << "Day total: " << day << (close(day, 83200) ? "  [OK]\n" : "  [FAIL]\n");
    if (!close(day, 83200)) ++failures;

    SelfPay sp;
    Insurance ins(60000, 20);
    GovernmentScheme gov;
    const Payer* payers[] = {&sp, &ins, &gov};
    // Hand calculation of amount covered
    //  SelfPay: 0 0 0 0
    //  Insurance 80% (limit 60000): 1360 40400 20000 4800
    //  Government (min(total, fixed rate)): 1000 30000 25000 5000
    const double expCov[3][4] = {{0, 0, 0, 0},
                                 {1360, 40400, 20000, 4800},
                                 {1000, 30000, 25000, 5000}};

    std::cout << "\n--- Each bill with each payer ---\n";
    std::cout << std::left << std::setw(22) << "Payer" << std::setw(6) << "Type"
              << std::right << std::setw(10) << "Total" << std::setw(10) << "Covered"
              << std::setw(12) << "PatientPays" << "  Check\n";
    for (int i = 0; i < 3; ++i)
        for (int j = 0; j < 4; ++j) {
            Settlement s = settle(*bills[j], *payers[i]);
            bool ok = close(s.covered, expCov[i][j]);
            if (!ok) ++failures;
            std::cout << std::left << std::setw(22) << payers[i]->name() << std::setw(6) << bills[j]->type()
                      << std::right << std::setw(10) << s.total << std::setw(10) << s.covered
                      << std::setw(12) << s.patientPays << (ok ? "  OK\n" : "  FAIL\n");
        }
    std::cout << "\nCore tests: " << (failures == 0 ? "ALL PASSED" : "FAILURES") << "\n";
    return failures;
}

// ====================== (1) Complete the Code (TODO 1..3 filled) ======================
namespace complete {
class Bill {
protected:
    std::string patient;
public:
    explicit Bill(const std::string& p) : patient(p) {}
    virtual ~Bill() = default;
    // TODO 1
    virtual double total() const = 0;
    virtual std::string type() const { return "Bill"; }
    void print() const { std::cout << type() << ' ' << patient << ": " << total() << '\n'; }
};
class OutPatient : public Bill {
    double consultation, tests;
public:
    OutPatient(const std::string& p, double c, double t) : Bill(p), consultation(c), tests(t) {}
    // TODO 2
    double total() const override { return consultation + tests; }
    std::string type() const override { return "OP"; }
};
class InPatient : public Bill {
    int days; double perDay, surgery;
public:
    InPatient(const std::string& p, int d, double rate, double s) : Bill(p), days(d), perDay(rate), surgery(s) {}
    // TODO 3
    double total() const override { return days * perDay + surgery; }
    std::string type() const override { return "IP"; }
};
void run()
{
    Bill* bills[] = {new OutPatient("Ravi", 500, 1200), new InPatient("Meena", 3, 2500, 40000)};
    double sum = 0;
    for (Bill* b : bills) { b->print(); sum += b->total(); }
    std::cout << "Total " << sum << '\n';
    for (Bill* b : bills) delete b;
    // Expected: OP Ravi: 1700 / IP Meena: 47500 / Total 49200
    // Experiment: remove 'virtual' from total() -> compile error "only virtual member functions can be made pure"
}
}

// ====================== (3) Alternative: templates, one container per type ======================
namespace tmpl {
struct OP { double c, t;    double total() const { return c + t; } };
struct IP { double d, r, x; double total() const { return d * r + x; } };
template <class B> double sumAll(const std::vector<B>& v) { double s = 0; for (auto& b : v) s += b.total(); return s; }
void run()
{
    std::vector<OP> ops{{500, 1200}, {100, 0}};
    std::vector<IP> ips{{3, 2500, 43000}};
    std::cout << "OP total=" << sumAll(ops) << "  IP total=" << sumAll(ips)
              << "  (two containers, no call through a common pointer, no run-time choice)\n";
}
}

// ====================== (4) B1.3 / B1.4 proofs ======================
#ifndef VT
#define VT virtual
#endif
#ifndef VD
#define VD virtual
#endif
namespace proofs {
struct Base {
    VD ~Base() { std::cout << "~Base\n"; }
    VT double total() const { return 0; }
};
struct Derived : Base {
    std::string owned = std::string(200, 'x');       // heap memory owned by Derived
    ~Derived() { std::cout << "~Derived\n"; }
    double total() const { return 1700; }
};
void run()
{
    Base* b = new Derived;
    std::cout << "total via Base*: " << b->total() << "   (1700 = virtual works, 0 = base version called)\n";
    std::cout.flush();
    delete b;                                        // non-virtual ~Base: ~Derived skipped, ASan reports
}
}

int main()
{
    std::cout << "##### (1) Complete the Code #####\n";   complete::run();
    std::cout << "\n##### (2) Every bill x every payer (B1.1) #####\n";
    int failures = runCoreTests();
    std::cout << "\n##### (3) Template alternative #####\n"; tmpl::run();
    std::cout << "\n##### (4) Runtime binding / virtual destructor proofs #####\n"; proofs::run();
    return failures == 0 ? 0 : 1;
}

// Q5 experiments: 10,000,000 prefix vs postfix increments, and checked vs unchecked access.
// Build and run at both levels:  g++ -std=c++17 -O0 ...   and   g++ -std=c++17 -O2 ...
#include <chrono>
#include <iostream>
#include <stdexcept>
#include <vector>
class Time {
    int h = 0, m = 0, s = 0;
public:
    Time& operator++() { if (++s == 60) { s = 0; if (++m == 60) { m = 0; ++h; } } return *this; }
    Time operator++(int) { Time old = *this; ++(*this); return old; }
    int seconds() const { return h * 3600 + m * 60 + s; }
};
int main() {
    const int N = 10000000;
    using clk = std::chrono::steady_clock;
    auto ms = [](clk::time_point a, clk::time_point b) { return std::chrono::duration<double, std::milli>(b - a).count(); };

    Time t1; auto a = clk::now(); for (int i = 0; i < N; ++i) ++t1; auto b = clk::now();
    Time t2; auto c = clk::now(); for (int i = 0; i < N; ++i) t2++; auto d = clk::now();
    std::cout << "prefix  ++t : " << ms(a, b) << " ms (check " << t1.seconds() << ")\n";
    std::cout << "postfix t++ : " << ms(c, d) << " ms (check " << t2.seconds() << ")\n";

    // checked vs unchecked access, 10,000,000 accesses
    std::vector<int> v(1000, 1);
    volatile long long sink = 0;
    auto e = clk::now();
    for (int i = 0; i < N; ++i) sink = sink + v[i % 1000];           // unchecked operator[]
    auto f = clk::now();
    for (int i = 0; i < N; ++i) sink = sink + v.at(i % 1000);        // checked at()
    auto g = clk::now();
    std::cout << "unchecked []  : " << ms(e, f) << " ms\n";
    std::cout << "checked at()  : " << ms(f, g) << " ms\n";
}

@echo off
REM Compile and run every program with MinGW g++ (Windows, VS Code terminal)
set FLAGS=-std=c++17 -Wall -Wextra
if not exist bin mkdir bin
call :run Q1 three_ways -O0
call :run Q1 predict_output -O0
call :run Q1 complete_code -O0
call :run Q2 marks_register -O0
call :run Q2 vector_invalidation -O0
call :run Q2 alt_index_pointer -O0
call :run Q3 courier -O0
call :run Q3 alt_parcel_template -O0
call :run Q4 account_shift -O0
call :run Q4 account_circular -O0
call :run Q4 account_deque -O0
call :run Q5 predict_output -O0
call :run Q5 complete_code -O0
call :run Q5 tickets_in_function -O0
call :run Q5 alt_ticket_office -O0
call :run Q6 complete_code -O0
call :run Q6 correctness_tests -O0
call :run Q6 inline_benchmark -O0
call :run Q6 inline_benchmark -O2
call :run Q7 redesign_benchmark -O2
echo Not run automatically: Q2\dangling_reference.cpp and Q3\ambiguous_error.cpp
goto :eof
:run
echo =============== %1\%2.cpp  (%3) ===============
g++ %FLAGS% %3 %1\%2.cpp -o bin\%1_%2_%3.exe && bin\%1_%2_%3.exe
echo.
goto :eof

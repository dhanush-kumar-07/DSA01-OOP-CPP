// Task 2 Alternative: composition (has-a) vs virtual-base diamond
#include <iostream>
#include <string>
struct Person { std::string name = "X"; int id = 0; };

// (A) diamond with virtual base
struct Student : virtual Person { double cgpa = 0; };
struct Staff   : virtual Person { double salary = 0; };
struct TA_inherit : Student, Staff {};

// (B) composition: each part has its OWN Person
struct StudentC { Person p; double cgpa = 0; };
struct StaffC   { Person p; double salary = 0; };
struct TA_compose { StudentC s; StaffC f; };

int main() {
    TA_inherit a; TA_compose b;
    std::cout << "sizeof(Person)            = " << sizeof(Person) << '\n';
    std::cout << "sizeof(TA_inherit, virtual)= " << sizeof(a) << "  (one Person + vbase pointers)\n";
    std::cout << "sizeof(TA_compose)        = " << sizeof(b) << "  (two Person objects)\n";
    a.name = "Arun";                                  // direct, unambiguous
    b.s.p.name = "Arun"; b.f.p.name = "Arun-Staff";   // two different names can exist!
    std::cout << "inherit: a.name = " << a.name << '\n';
    std::cout << "compose: b.s.p.name = " << b.s.p.name << ", b.f.p.name = " << b.f.p.name << '\n';
}

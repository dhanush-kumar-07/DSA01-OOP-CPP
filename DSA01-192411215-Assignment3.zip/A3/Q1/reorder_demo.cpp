// Q1 experiment: members are initialised in DECLARATION order, not list order.
// Compile with: g++ -std=c++17 -Wall -Wextra Q1/reorder_demo.cpp  -> -Wreorder warning
#include <iostream>
class Wrong {
    int first;    // declared first  -> initialised first
    int second;   // declared second
public:
    Wrong(int v) : second(v), first(second + 1) {}   // list order differs from declaration order
    void print() const { std::cout << "first=" << first << " (garbage!), second=" << second << '\n'; }
};
int main() { Wrong w(10); w.print(); }

// Task 5 Alternative: std::vector<Cart> (objects) instead of an array of Cart*
#include <cstdint>
#include <iostream>
#include <string>
#include <vector>
struct Cart { std::string items[10]; double prices[10] = {}; int n = 0; double total() const { double t=0; for(int i=0;i<n;++i) t+=prices[i]; return t; } };
int main() {
    std::vector<Cart> v;
    v.push_back(Cart());
    std::uintptr_t before = reinterpret_cast<std::uintptr_t>(&v[0]);   // remember address of first cart
    std::cout << "sizeof(Cart) = " << sizeof(Cart) << " bytes stored per element; a pointer is " << sizeof(Cart*) << " bytes\n";
    std::cout << "capacity before: " << v.capacity() << '\n';
    for (int i = 0; i < 100; ++i) v.push_back(Cart());                 // growth -> reallocation
    std::uintptr_t after = reinterpret_cast<std::uintptr_t>(&v[0]);
    std::cout << "capacity after : " << v.capacity() << '\n';
    std::cout << "first element moved: " << (before != after ? "YES - old pointers/references are now dangling" : "no") << '\n';
    // highest total: O(n) loop, same as the pointer array
    double best = 0; for (const auto& c : v) if (c.total() > best) best = c.total();
    std::cout << "best total = " << best << '\n';
}

// ===== TASK A3 - Abstract Payer design + extension (run this ONE file) =====
// Build: g++ -std=c++17 -Wall -Wextra -fsanitize=address -g main.cpp -o a3 && ./a3
#include <algorithm>
#include <functional>
#include <iostream>
#include <map>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

class ClaimError : public std::runtime_error { public: using std::runtime_error::runtime_error; };

struct Bill {                                          // minimal bill for the payer tests
    std::string type; double total;
};

// ---- A3.1 : abstract Payer ----
class Payer {
public:
    virtual ~Payer() = default;
    virtual double amountCovered(const Bill& b) const = 0;     // pure virtual
    virtual std::string name() const = 0;
};
class SelfPay : public Payer {
public:
    double amountCovered(const Bill&) const override { return 0; }
    std::string name() const override { return "SelfPay"; }
};
class Insurance : public Payer {
    double limit, copayPct;
public:
    Insurance(double l, double c) : limit(l), copayPct(c) {}
    double amountCovered(const Bill& b) const override
    {
        if (b.total > limit) throw ClaimError("exceeds cover limit");
        return b.total * (1 - copayPct / 100);
    }
    std::string name() const override { return "Insurance"; }
};
class GovernmentScheme : public Payer {
    std::map<std::string, double> rate{{"OP", 1000}, {"IP", 30000}, {"DC", 25000}, {"ER", 5000}};
public:
    double amountCovered(const Bill& b) const override
    {
        auto it = rate.find(b.type);
        if (it == rate.end()) throw ClaimError("no package rate for " + b.type);
        return std::min(b.total, it->second);
    }
    std::string name() const override { return "GovScheme"; }
};

// ---- A3.2 : extension - NEW class only, nothing above is edited ----
class CorporateTieUp : public Payer {
    double pct, cap;
public:
    CorporateTieUp(double p, double c) : pct(p), cap(c) {}
    double amountCovered(const Bill& b) const override { return std::min(b.total * pct / 100, cap); }
    std::string name() const override { return "Corporate"; }
};

// ---- Alternative: payers as std::function (policy chosen at run time) ----
using PayerFn = std::function<double(const Bill&)>;
PayerFn insuranceFn(double limit, double copay)           // limit/co-pay live inside the lambda capture
{
    return [=](const Bill& b) {
        if (b.total > limit) throw ClaimError("exceeds cover limit");
        return b.total * (1 - copay / 100);
    };
}

int main()
{
    std::vector<Bill> bills{{"OP", 1700}, {"IP", 50500}};
    std::vector<std::unique_ptr<Payer>> payers;
    payers.push_back(std::make_unique<SelfPay>());
    payers.push_back(std::make_unique<Insurance>(60000, 20));
    payers.push_back(std::make_unique<GovernmentScheme>());
    payers.push_back(std::make_unique<CorporateTieUp>(90, 40000));     // added WITHOUT changing old classes

    std::cout << "=== Abstract Payer hierarchy ===\n";
    for (auto& p : payers)
        for (auto& b : bills)
            std::cout << p->name() << " covers " << b.total << " (" << b.type << ") -> " << p->amountCovered(b) << '\n';

    std::cout << "\n=== A claim above the cover is rejected ===\n";
    try { Insurance(10000, 20).amountCovered(bills[1]); }
    catch (const ClaimError& e) { std::cout << "ClaimError: " << e.what() << '\n'; }

    std::cout << "\n=== Alternative: std::function payer ===\n";
    PayerFn f = insuranceFn(60000, 20);
    std::cout << "insuranceFn covers " << f(bills[1]) << "   sizeof(std::function)=" << sizeof(PayerFn)
              << "  sizeof(Insurance)=" << sizeof(Insurance) << '\n';
}

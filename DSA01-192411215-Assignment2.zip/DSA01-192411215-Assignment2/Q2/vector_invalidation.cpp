// Q2 - Changed condition: references into a growing std::vector can become invalid
#include <iostream>
#include <vector>

int main() {
    std::vector<int> marks = {72, 88, 65, 91};
    marks.shrink_to_fit();
    int* before = &marks[0];                    // address (same thing a reference holds)
    std::cout << "capacity before : " << marks.capacity() << ", &marks[0] = " << before << '\n';

    marks.push_back(79);                        // exceeds capacity -> reallocation
    std::cout << "capacity after  : " << marks.capacity() << ", &marks[0] = " << &marks[0] << '\n';

    if (before != &marks[0])
        std::cout << "Storage MOVED: any reference/pointer taken earlier is now dangling.\n";
    else
        std::cout << "Storage did not move this time (capacity was enough).\n";
    // We deliberately do NOT use *before here - that would be undefined behaviour.

    // Safe alternative: remember the INDEX, not the address.
    std::size_t idx = 3;
    marks.push_back(60); marks.push_back(61); marks.push_back(62);
    marks[idx] += 2;
    std::cout << "marks[3] via index after growth: " << marks[idx] << '\n';
}

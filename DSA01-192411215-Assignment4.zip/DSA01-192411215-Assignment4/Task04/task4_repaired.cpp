// Task 4.3 - repaired program
#include <iostream>
class Account {
public:
    virtual ~Account() = default;                                  // virtual destructor
    virtual double rate() const { return 3.5; }                    // virtual function
};
class SeniorAccount : public Account {
    double* history = new double[100];
public:
    SeniorAccount() = default;
    SeniorAccount(const SeniorAccount&) = delete;                  // owns raw memory: forbid shallow copy
    SeniorAccount& operator=(const SeniorAccount&) = delete;
    ~SeniorAccount() override { delete[] history; std::cout << "  ~SeniorAccount: history freed\n"; }
    double rate() const override { return 4.0; }                   // override checked by compiler
};
void show(const Account& a) { std::cout << "  via reference: " << a.rate() << '\n'; }   // reference, no copy

int main() {
    Account* accounts[2] = { new Account, new SeniorAccount };
    for (Account* a : accounts) std::cout << a->rate() << "\n";    // 3.5 and 4.0
    show(*accounts[1]);
    for (Account* a : accounts) delete a;                          // full destruction chain runs
    // Account copy = SeniorAccount();   // would still slice; avoid copying polymorphic objects
}

// Task 7 - Alternative: balance as a PUBLIC data member
#include <iostream>

struct SmartCard {
    long long balance;                      // public: anyone can write it
};

int main()
{
    SmartCard c{10000};
    c.balance = 100;                        // below Rs 50, no check
    c.balance -= 5000;                      // negative balance
    std::cout << "balance = " << c.balance << " paise -> Rule 'never below Rs 50' broken by ordinary code\n";
}

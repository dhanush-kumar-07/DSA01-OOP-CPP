// Q4 - Money class: +, -, +=, -=, ==, !=, <, <<, >>  + bill calculation + double comparison.
#include <chrono>
#include <iomanip>
#include <iostream>
#include <sstream>

class Money {
    long long paise;
public:
    Money(long long rupees = 0, int p = 0) : paise(rupees * 100 + p) {}

    // member operators: left operand is a Money (modifies or reads *this)
    Money& operator+=(const Money& o) { paise += o.paise; return *this; }   // returns *this (no copy)
    Money& operator-=(const Money& o) { paise -= o.paise; return *this; }
    bool operator==(const Money& o) const { return paise == o.paise; }
    bool operator!=(const Money& o) const { return !(*this == o); }
    bool operator<(const Money& o) const { return paise < o.paise; }

    // friends: symmetric binary operators + stream operators (left operand is NOT a Money)
    friend Money operator+(Money a, const Money& b) { a += b; return a; }   // returns NEW object
    friend Money operator-(Money a, const Money& b) { a -= b; return a; }
    friend std::ostream& operator<<(std::ostream& os, const Money& m) {
        long long a = m.paise < 0 ? -m.paise : m.paise;
        os << "Rs " << (m.paise < 0 ? "-" : "") << a / 100 << '.'
           << std::setfill('0') << std::setw(2) << a % 100 << std::setfill(' ');
        return os;
    }
    friend std::istream& operator>>(std::istream& is, Money& m) {   // reads: rupees paise
        long long r; int p;
        if (is >> r >> p) m = Money(r, p);
        return is;
    }
    double toDouble() const { return paise / 100.0; }
};

int main() {
    // --- Bill calculation with operators ---
    Money item1(120, 50), item2(79, 25), item3(15), discount(20, 0);
    Money total = item1 + item2 + item3 - discount;
    std::cout << "Bill total: " << total << '\n';
    total += Money(0, 75);
    std::cout << "After adding Rs 0.75 tip: " << total << '\n';

    // --- Carry test ---
    std::cout << "Carry test  Rs 0.75 + Rs 0.50 = " << Money(0, 75) + Money(0, 50) << '\n';

    // --- Negative result ---
    Money neg = Money(10) - Money(10, 25);
    std::cout << "Negative test Rs 10.00 - Rs 10.25 = " << neg << "  (allowed: shown with minus sign; caller may check < Money())\n";
    if (neg < Money()) std::cout << "  -> detected as a negative balance\n";

    // --- Comparisons ---
    std::cout << std::boolalpha << "Money(5) < Money(6): " << (Money(5) < Money(6))
              << ", Money(5) == Money(5): " << (Money(5) == Money(5))
              << ", Money(5) != Money(5,1): " << (Money(5) != Money(5, 1)) << '\n';

    // --- Reading with >> (from a string stream, so no typing needed) ---
    std::istringstream in("42 5");
    Money read; in >> read;
    std::cout << "Read from '42 5': " << read << '\n';

    // --- 1,000,000 additions of Rs 0.10: Money vs double ---
    Money m; double d = 0.0;
    auto t0 = std::chrono::steady_clock::now();
    for (int i = 0; i < 1000000; ++i) m += Money(0, 10);
    auto t1 = std::chrono::steady_clock::now();
    for (int i = 0; i < 1000000; ++i) d += 0.10;
    auto t2 = std::chrono::steady_clock::now();
    std::cout << std::fixed << std::setprecision(10);
    std::cout << "Money result : " << m << "  (exact)  time " << std::chrono::duration<double, std::milli>(t1 - t0).count() << " ms\n";
    std::cout << "double result: " << d << "  error = " << d - 100000.0 << "  time " << std::chrono::duration<double, std::milli>(t2 - t1).count() << " ms\n";
}

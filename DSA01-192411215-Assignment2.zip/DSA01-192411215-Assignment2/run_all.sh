#!/bin/bash
# Compile and run every program (Linux / macOS / Git-Bash / WSL)
FLAGS="-std=c++17 -Wall -Wextra"
mkdir -p bin
run() {  # run <folder> <file> [extra flags]
  f="$1/$2"; out="bin/$1_${2%.cpp}"
  echo "=============== $f ==============="
  g++ $FLAGS $3 "$f" -o "$out" && "$out"
  echo
}
run Q1 three_ways.cpp;       run Q1 predict_output.cpp;   run Q1 complete_code.cpp
run Q2 marks_register.cpp;   run Q2 vector_invalidation.cpp; run Q2 alt_index_pointer.cpp
run Q3 courier.cpp;          run Q3 alt_parcel_template.cpp
run Q4 account_shift.cpp;    run Q4 account_circular.cpp; run Q4 account_deque.cpp
run Q5 predict_output.cpp;   run Q5 complete_code.cpp;    run Q5 tickets_in_function.cpp; run Q5 alt_ticket_office.cpp
run Q6 complete_code.cpp;    run Q6 correctness_tests.cpp
echo "---- Q6 benchmark -O0 ----";  run Q6 inline_benchmark.cpp -O0
echo "---- Q6 benchmark -O2 ----";  run Q6 inline_benchmark.cpp -O2
run Q7 redesign_benchmark.cpp -O2
echo "Not run automatically (they demonstrate errors/UB): Q2/dangling_reference.cpp, Q3/ambiguous_error.cpp"

// Q5 - ++ (prefix/postfix), ==, <, and operator[] with range check (const and non-const)
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

class Time {
    int h, m, s;
public:
    Time(int hh = 0, int mm = 0, int ss = 0) : h(hh), m(mm), s(ss) {}
    Time& operator++() {                 // prefix: advance, return the new value by reference
        if (++s == 60) { s = 0; if (++m == 60) { m = 0; ++h; } }
        return *this;
    }
    Time operator++(int) {               // postfix: dummy int; returns a COPY of the old value
        Time old = *this;
        ++(*this);
        return old;
    }
    bool operator==(const Time& o) const { return h == o.h && m == o.m && s == o.s; }
    bool operator<(const Time& o) const {
        if (h != o.h) return h < o.h;
        if (m != o.m) return m < o.m;
        return s < o.s;
    }
    friend std::ostream& operator<<(std::ostream& os, const Time& t) {
        return os << t.h << ':' << std::setfill('0') << std::setw(2) << t.m << ':' << std::setw(2) << t.s << std::setfill(' ');
    }
};

class Playlist {
    std::vector<std::string> tracks;
public:
    void add(const std::string& t) { tracks.push_back(t); }
    std::size_t size() const { return tracks.size(); }

    std::string& operator[](int i) {                 // non-const: allows playlist[i] = "new"
        if (i < 0 || i >= (int)tracks.size()) {
            std::cerr << "  ERROR: index " << i << " out of range (size " << tracks.size() << ")\n";
            throw std::out_of_range("Playlist index");
        }
        return tracks[i];
    }
    const std::string& operator[](int i) const {     // const: usable on const Playlist
        if (i < 0 || i >= (int)tracks.size()) {
            std::cerr << "  ERROR: index " << i << " out of range (size " << tracks.size() << ")\n";
            throw std::out_of_range("Playlist index");
        }
        return tracks[i];
    }
};

void printAll(const Playlist& p) {                   // forces the const version of []
    for (std::size_t i = 0; i < p.size(); ++i) std::cout << "  " << i << ": " << p[(int)i] << '\n';
}

int main() {
    Time t(0, 0, 58);
    Time a = t++;    // a gets OLD value
    std::cout << "a = t++ -> a=" << a << ", t=" << t << '\n';
    Time b = ++t;    // b gets NEW value
    std::cout << "b = ++t -> b=" << b << ", t=" << t << '\n';

    Time r(0, 59, 59);
    ++r; std::cout << "Roll-over 0:59:59 -> " << r << '\n';
    Time d(23, 59, 59);
    ++d; std::cout << "Roll-over 23:59:59 -> " << d << " (hours keep counting)\n";
    std::cout << std::boolalpha << "0:01:00 == 0:01:00: " << (Time(0, 1, 0) == Time(0, 1, 0))
              << ", 0:00:59 < 0:01:00: " << (Time(0, 0, 59) < Time(0, 1, 0)) << '\n';

    Playlist pl;
    pl.add("Vande Mataram"); pl.add("Jai Ho"); pl.add("Kun Faya Kun");
    printAll(pl);
    pl[1] = "Chaiyya Chaiyya";
    std::cout << "After pl[1] = ... -> " << pl[1] << '\n';

    for (int idx : {-1, (int)pl.size()}) {
        std::cout << "Test playlist[" << idx << "]:\n";
        try { pl[idx]; } catch (const std::out_of_range&) { std::cout << "  caught out_of_range\n"; }
    }

    std::cout << "--- Playback simulation ---\n";
    Time now(0, 0, 0), end(0, 0, 5);
    int track = 0;
    while (now < end) {
        std::cout << "  " << now << "  playing: " << pl[track % (int)pl.size()] << '\n';
        ++now;
        if (now == Time(0, 0, 3)) ++track;
    }
}

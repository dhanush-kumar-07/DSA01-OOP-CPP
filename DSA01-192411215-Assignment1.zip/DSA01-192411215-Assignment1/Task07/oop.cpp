// Task 7 - OBJECT-ORIENTED version: SmartCard with private balance, deduct() and canTravel()
#include <iostream>

class SmartCard {
public:
    explicit SmartCard(long long paise) : balance_(paise < 0 ? 0 : paise) {}
    bool canTravel(long long fare) const { return fare >= 0 && balance_ - fare >= MIN_BALANCE_PAISE; }
    bool deduct(long long fare)
    {
        if (!canTravel(fare)) return false;      // the only way to reduce the balance
        balance_ -= fare;
        return true;
    }
    bool recharge(long long paise)
    {
        if (paise <= 0) return false;            // negative recharge rejected
        balance_ += paise;
        return true;
    }
    long long balance() const { return balance_; }
private:
    static constexpr long long MIN_BALANCE_PAISE = 5000;   // change the rule in ONE place
    long long balance_;
};

long long fare(int zone, bool peak)
{
    long long base = (zone == 0) ? 1000 : (zone == 1) ? 2000 : 3000;
    return peak ? base + base * 20 / 100 : base;
}

int main()
{
    SmartCard card(10000);
    struct T { int zone; bool peak; } trips[] = {{0, false}, {2, true}, {1, false}};
    for (const T& t : trips) {
        long long f = fare(t.zone, t.peak);
        if (card.deduct(f)) std::cout << "paid " << f << ", balance " << card.balance() << '\n';
        else std::cout << "denied, balance " << card.balance() << '\n';
    }
    // card.balance_ -= 9999;   // COMPILE ERROR: 'balance_' is private
    std::cout << "negative recharge accepted? " << card.recharge(-500) << " (0 = rejected)\n";
    std::cout << "final balance " << card.balance() << " paise (rule holds)\n";
}

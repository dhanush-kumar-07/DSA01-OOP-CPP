// Q1 design question: explicit constructor.
// Compile normally            -> compiles (implicit conversion string -> Book)
// Compile with -DUSE_EXPLICIT -> ERROR: could not convert 'std::string' to 'Book'
#include <iostream>
#include <string>
class Book {
    std::string title;
public:
#ifdef USE_EXPLICIT
    explicit
#endif
    Book(std::string t) : title(std::move(t)) {}
    void print() const { std::cout << "Book: " << title << '\n'; }
};
void show(Book b) { b.print(); }
int main() {
    show(std::string("Gitanjali"));   // implicit conversion: allowed only without explicit
    show(Book("Gitanjali"));          // always fine
}

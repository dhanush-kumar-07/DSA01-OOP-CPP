// Task 6 - journeys at exactly 10 AM and 8 PM (and 8 AM, 5 PM) to check the peak rule; table-lookup alternative
#include <iostream>

enum class Zone { Inner, Middle, Outer };
constexpr long long FARE[] = {1000, 2000, 3000};   // alternative: array indexed by zone
constexpr int PEAK_PERCENT = 20;

constexpr bool isPeak(int hour) { return (hour >= 8 && hour < 10) || (hour >= 17 && hour < 20); }

long long fare(Zone z, bool peak)
{
    long long base = FARE[static_cast<int>(z)];    // O(1) lookup; a 4th zone = one new array value
    return peak ? base + base * PEAK_PERCENT / 100 : base;
}

int main()
{
    int hours[] = {8, 10, 17, 20};
    for (int h : hours)
        std::cout << "Outer zone at " << h << ":00 -> " << (isPeak(h) ? "peak" : "off-peak")
                  << ", fare " << fare(Zone::Outer, isPeak(h)) << " paise\n";
    static_assert(isPeak(8) && !isPeak(10) && isPeak(17) && !isPeak(20), "boundary rule: start inclusive, end exclusive");
    std::cout << "Rule: start hour inclusive, end hour exclusive -> 10:00 and 20:00 are OFF-peak.\n";
}

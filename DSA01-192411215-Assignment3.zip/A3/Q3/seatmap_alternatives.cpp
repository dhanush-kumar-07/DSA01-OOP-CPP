// Q3 alternative: (1) one contiguous block r*seats+s, (2) vector<vector<char>>.
#include <iostream>
#include <vector>
class FlatMap {
    int rows, seats; char* data;
public:
    FlatMap(int r, int s) : rows(r), seats(s), data(new char[(std::size_t)r * s]) { for (int i = 0; i < r * s; ++i) data[i] = '.'; }
    ~FlatMap() { delete[] data; }
    FlatMap(const FlatMap&) = delete; FlatMap& operator=(const FlatMap&) = delete;
    char& at(int r, int s) { return data[r * seats + s]; }    // index = r * seats + s
};
int main() {
    FlatMap f(3, 4);                       // 1 allocation
    f.at(1, 2) = 'X';
    std::vector<std::vector<char>> v(3, std::vector<char>(4, '.'));   // rows+1 allocations
    v[1][2] = 'X';
    std::cout << "flat: " << f.at(1, 2) << "  vector: " << v[1][2] << '\n';
}

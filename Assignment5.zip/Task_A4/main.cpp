// ===== TASK A4 - Exception strategy (run this ONE file) =====
// Build: g++ -std=c++17 -Wall -Wextra -fsanitize=address -g main.cpp -o a4 && ./a4
#include <iostream>
#include <new>
#include <stdexcept>
#include <string>

// ---- A4.1 : hierarchy derived from std::exception ----
class BillingError : public std::runtime_error { public: using std::runtime_error::runtime_error; };
class NegativeChargeError : public BillingError { public: using BillingError::BillingError; };
class ClaimError          : public BillingError { public: using BillingError::BillingError; };
class UnknownPackageError : public BillingError { public: using BillingError::BillingError; };
class MissingRecordError  : public BillingError { public: using BillingError::BillingError; };
// memory allocation failure -> std::bad_alloc (standard)

// ---- A4.2 : which functions may throw / must never throw ----
double checkCharge(double v)                       // may throw
{
    if (v < 0) throw NegativeChargeError("negative charge");
    return v;
}
double claim(double billed, double cover)          // may throw
{
    if (billed > cover) throw ClaimError("claim above cover");
    return billed;
}
double packagePrice(const std::string& code)       // may throw
{
    if (code == "CATARACT") return 25000;
    throw UnknownPackageError("unknown package " + code);
}
void findPatient(const std::string& n)             // may throw
{
    if (n != "Ravi") throw MissingRecordError("missing record " + n);
}
double plainTotal(double a, double b) noexcept { return a + b; }   // must never throw

struct Resource {                                  // destructors are noexcept by default
    ~Resource() noexcept { std::cout << "  ~Resource (destructor must not throw)\n"; }
};

template <class F>
void attempt(const char* label, F f)
{
    std::cout << label << ": ";
    try { f(); std::cout << "ok\n"; }
    catch (const ClaimError& e)   { std::cout << "ClaimError - "   << e.what() << '\n'; }
    catch (const BillingError& e) { std::cout << "BillingError - " << e.what() << '\n'; }
    catch (const std::bad_alloc&) { std::cout << "bad_alloc\n"; }
    catch (const std::exception& e) { std::cout << "std::exception - " << e.what() << '\n'; }
}

// ---- Alternative: return codes ----
enum class Status { Ok, Negative, AboveCover };
Status claimRC(double billed, double cover, double& out)   // result must travel via a parameter
{
    if (billed < 0) return Status::Negative;
    if (billed > cover) return Status::AboveCover;
    out = billed; return Status::Ok;
}

int main()
{
    std::cout << "=== Error list, each thrown and caught ===\n";
    attempt("negative charges   ", [] { checkCharge(-5); });
    attempt("claim above cover  ", [] { claim(60000, 50000); });
    attempt("unknown package    ", [] { packagePrice("BYPASS"); });
    attempt("missing record     ", [] { findPatient("Ghost"); });
    attempt("stod on text       ", [] { std::stod("abc"); });
    attempt("allocation failure ", [] {
#if defined(__SANITIZE_ADDRESS__)
        volatile std::size_t n = ~std::size_t(0) / 2;      // overflow -> bad_array_new_length (a bad_alloc)
#else
        volatile std::size_t n = std::size_t(1) << 50;
#endif
        double* p = new double[n]; p[0] = 1; delete[] p;
    });
    attempt("RAII + exception   ", [] { Resource r; checkCharge(-1); });

    std::cout << "\nnoexcept check: noexcept(plainTotal(1,2)) = " << std::boolalpha << noexcept(plainTotal(1, 2))
              << ", noexcept(claim(1,2)) = " << noexcept(claim(1, 2)) << '\n';

    std::cout << "\n=== Alternative: return codes ===\n";
    double out = 0;
    for (double b : {40000.0, 60000.0, -1.0}) {
        Status s = claimRC(b, 50000, out);                 // every caller MUST remember to check
        std::cout << "billed " << b << " -> status " << int(s) << '\n';
    }
}

// Task 1 Alternative: ONE Staff class with a type field and a switch in pay()
#include <iostream>
#include <string>
#include <vector>

enum class Type { Professor, LabAssistant, GuestFaculty };

struct Staff {
    Type type;
    std::string name; int id;
    double basic = 0, research = 0;   // unused for GuestFaculty
    double hours = 0, rate = 0;       // unused for Professor / LabAssistant
    double pay() const {
        switch (type) {
            case Type::Professor:    return basic + basic * 0.42 + research;
            case Type::LabAssistant: return basic + basic * 0.42;
            case Type::GuestFaculty: return hours * rate;
        }
        return 0;
    }
};

int main() {
    std::vector<Staff> v = {
        {Type::Professor, "Meena", 101, 80000, 10000, 0, 0},
        {Type::LabAssistant, "Ravi", 102, 30000, 0, 0, 0},
        {Type::GuestFaculty, "Anand", 201, 0, 0, 40, 1500}};
    for (const auto& s : v) std::cout << s.name << " " << s.pay() << '\n';
    std::cout << "sizeof(Staff) = " << sizeof(Staff) << " bytes for EVERY object\n";
    // Adding a new type: edit enum + edit switch in pay() (+ every other switch) + add fields to Staff.
}

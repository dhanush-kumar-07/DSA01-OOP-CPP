#!/usr/bin/env bash
# Compiles and runs every program. Output of each is saved next to the source as <name>.out.txt
FLAGS="-std=c++17 -Wall -Wextra"
run() {   # run <dir> <source> [extra compile flags]
    d="$1"; src="$2"; shift 2
    exe="$d/${src%.cpp}.exe"
    echo "=== $d/$src $* ==="
    g++ $FLAGS "$@" "$d/$src" -o "$exe" 2>"$d/${src%.cpp}.compile.txt"
    cat "$d/${src%.cpp}.compile.txt"
    "$exe" | tee "$d/${src%.cpp}.out.txt"
    echo
}
run Task01 task1_repaired.cpp
run Task01 task1_alt_switch.cpp

run Task02 task2_people.cpp
run Task02 task2_access_table.cpp
run Task02 task2_predict.cpp
run Task02 task2_alt_composition.cpp
mv Task02/task2_predict.out.txt Task02/task2_predict_virtual.out.txt
echo "--- without virtual ---"; g++ $FLAGS -DVIRT= Task02/task2_predict.cpp -o Task02/novirt.exe 2>&1 | tee Task02/novirt.compile.txt
./Task02/novirt.exe | tee Task02/task2_predict_novirtual.out.txt

run Task03 task3_construction.cpp
run Task03 task3_predict.cpp
run Task03 task3_complete.cpp
echo "--- reordered initializer list (look for -Wreorder warning) ---"
g++ $FLAGS Task03/task3_complete_reordered.cpp -o Task03/reordered.exe 2>&1 | tee Task03/reordered.compile.txt
./Task03/reordered.exe
echo "--- experiment: virtual ---";   g++ $FLAGS Task03/task3_experiment.cpp -o Task03/exp_v.exe && ./Task03/exp_v.exe | tee Task03/experiment_virtual.out.txt
echo "--- experiment: no virtual ---"; g++ $FLAGS -DVIRT= Task03/task3_experiment.cpp -o Task03/exp_nv.exe && ./Task03/exp_nv.exe | tee Task03/experiment_novirtual.out.txt
run Task03 task3_alt_pointer_member.cpp

run Task04 task4_defects.cpp
echo "--- AddressSanitizer (leak report; type-mismatch check disabled so the program continues) ---"
g++ $FLAGS -g -fsanitize=address Task04/task4_defects.cpp -o Task04/defects_asan.exe
ASAN_OPTIONS=new_delete_type_mismatch=0:detect_leaks=1 ./Task04/defects_asan.exe > Task04/asan_leak.out.txt 2>&1; cat Task04/asan_leak.out.txt
echo "--- AddressSanitizer default (reports new-delete-type-mismatch) ---"
./Task04/defects_asan.exe > Task04/asan_default.out.txt 2>&1; head -20 Task04/asan_default.out.txt
run Task04 task4_repaired.cpp
g++ $FLAGS -g -fsanitize=address Task04/task4_repaired.cpp -o Task04/repaired_asan.exe && ./Task04/repaired_asan.exe > Task04/repaired_asan.out.txt 2>&1 && echo "repaired + ASan: clean (no errors)"
run Task04 task4_predict.cpp
run Task04 task4_alt_unique_ptr.cpp

run Task05 task5_four_ways.cpp
run Task05 task5_complete.cpp
run Task05 task5_complete_byvalue.cpp
run Task05 task5_alt_vector.cpp

echo "=== Task06 ==="
g++ $FLAGS Task06/main.cpp -o Task06/fleet.exe && ./Task06/fleet.exe | tee Task06/fleet.out.txt
run Task06 task6_alt_switch.cpp

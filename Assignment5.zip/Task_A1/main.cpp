// ===== TASK A1 - Design the polymorphic bill hierarchy (run this ONE file) =====
// Build: g++ -std=c++17 -Wall -Wextra -fsanitize=address -g main.cpp -o a1 && ./a1
// Shows: common interface (A1.1), hierarchy with pure virtual functions (A1.2),
//        day total through an array of Bill* (A1.3), and the switch-based alternative.
#include <iostream>
#include <memory>
#include <string>
#include <vector>

// ---- A1.1 / A1.2 : abstract base class ----
class Bill {
protected:
    std::string patient;                                  // data common to all bills
public:
    explicit Bill(std::string p) : patient(std::move(p)) {}
    virtual ~Bill() = default;                            // virtual
    virtual double total() const = 0;                     // pure virtual
    virtual std::string type() const = 0;                 // pure virtual
    void print() const { std::cout << type() << ' ' << patient << ": " << total() << '\n'; }
};

class OutPatientBill : public Bill {                      // consultation + tests
    double consultation, tests;
public:
    OutPatientBill(std::string p, double c, double t) : Bill(std::move(p)), consultation(c), tests(t) {}
    double total() const override { return consultation + tests; }       // overridden
    std::string type() const override { return "OP"; }
};
class InPatientBill : public Bill {                       // days*rate + procedures + medicines
    int days; double perDay, procedures, medicines;
public:
    InPatientBill(std::string p, int d, double r, double pr, double m)
        : Bill(std::move(p)), days(d), perDay(r), procedures(pr), medicines(m) {}
    double total() const override { return days * perDay + procedures + medicines; }
    std::string type() const override { return "IP"; }
};
class DayCareBill : public Bill {                         // package price
    double packagePrice;
public:
    DayCareBill(std::string p, double price) : Bill(std::move(p)), packagePrice(price) {}
    double total() const override { return packagePrice; }
    std::string type() const override { return "DC"; }
};
class EmergencyBill : public Bill {                       // base + time-based charge
    double base, hours, rate;
public:
    EmergencyBill(std::string p, double b, double h, double r) : Bill(std::move(p)), base(b), hours(h), rate(r) {}
    double total() const override { return base + hours * rate; }
    std::string type() const override { return "ER"; }
};

// ---- A1.3 : day's total through base-class pointers ----
double dayTotal(Bill* const* bills, std::size_t n)
{
    double sum = 0;
    for (std::size_t i = 0; i < n; ++i) sum += bills[i]->total();    // virtual call per bill, O(n)
    return sum;
}

// ---- Alternative concept: ONE struct with a type field + switch ----
namespace alt {
enum class Kind { OP, IP, DC, ER };
struct SBill { Kind kind; double a, b, c; };              // every bill pays for the largest layout
double total(const SBill& x)
{
    switch (x.kind) {                                     // new bill type => edit this switch (and all others)
        case Kind::OP: return x.a + x.b;
        case Kind::IP: return x.a * x.b + x.c;
        case Kind::DC: return x.a;
        case Kind::ER: return x.a + x.b * x.c;
    }
    return 0;
}
}

int main()
{
    std::cout << "=== A1: polymorphic hierarchy ===\n";
    Bill* bills[] = {new OutPatientBill("Ravi", 500, 1200),
                     new InPatientBill("Meena", 3, 2500, 40000, 3000),
                     new DayCareBill("Arun", 25000),
                     new EmergencyBill("Divya", 3000, 2, 1500)};
    for (Bill* b : bills) b->print();
    std::cout << "Day total (virtual) = " << dayTotal(bills, 4) << "   [hand check: 1700+50500+25000+6000 = 83200]\n";
    std::cout << "sizeof(OutPatientBill)=" << sizeof(OutPatientBill) << " (includes the vptr and the string)\n";
    for (Bill* b : bills) delete b;

    std::cout << "\n=== Alternative: struct + switch ===\n";
    std::vector<alt::SBill> v{{alt::Kind::OP, 500, 1200, 0}, {alt::Kind::IP, 3, 2500, 43000},
                              {alt::Kind::DC, 25000, 0, 0}, {alt::Kind::ER, 3000, 2, 1500}};
    double s = 0;
    for (auto& b : v) s += alt::total(b);
    std::cout << "Day total (switch)  = " << s << "   sizeof(SBill)=" << sizeof(alt::SBill) << '\n';
}

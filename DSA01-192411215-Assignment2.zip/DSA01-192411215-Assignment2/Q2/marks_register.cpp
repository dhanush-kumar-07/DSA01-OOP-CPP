// Q2 - Return by reference: highest mark can be moderated in place
#include <iostream>

int& highest(int marks[], int n) {                 // returns a reference to the element
    int idx = 0;
    for (int i = 1; i < n; ++i) if (marks[i] > marks[idx]) idx = i;
    return marks[idx];
}
const int& highestConst(const int marks[], int n) { // read-only reference
    int idx = 0;
    for (int i = 1; i < n; ++i) if (marks[i] > marks[idx]) idx = i;
    return marks[idx];
}
int highestCopy(const int marks[], int n) {          // returns a copy
    int idx = 0;
    for (int i = 1; i < n; ++i) if (marks[i] > marks[idx]) idx = i;
    return marks[idx];
}
void print(const char* label, const int m[], int n) {
    std::cout << label;
    for (int i = 0; i < n; ++i) std::cout << m[i] << ' ';
    std::cout << '\n';
}

int main() {
    int marks[] = {72, 88, 65, 91, 79};
    const int n = 5;
    print("original              : ", marks, n);

    highest(marks, n) += 2;                 // moderation applied directly to the array element
    print("after highest()+=2    : ", marks, n);

    highest(marks, n) = 95;                 // call on the LEFT of =
    print("after highest()=95    : ", marks, n);

    int copy = highestCopy(marks, n);       // copy: changing it does not touch the array
    copy += 2;
    print("after copy += 2       : ", marks, n);

    const int& cr = highestConst(marks, n); // cr = 95, cannot write through it
    // cr += 2;                             // ERROR: assignment of read-only reference
    std::cout << "const reference reads: " << cr << '\n';
}

// Q4 Complete the Code: TODO 1 and TODO 2 completed.
#include <iomanip>
#include <iostream>
class Money {
    long long paise;
public:
    Money(long long rupees = 0, int p = 0) : paise(rupees * 100 + p) {}

    // TODO 1: + as a member function returning a new Money
    Money operator+(const Money& other) const {
        Money result;
        result.paise = paise + other.paise;
        return result;
    }

    // TODO 2: == as a member, << as a friend that prints "Rs 200.00"
    bool operator==(const Money& other) const { return paise == other.paise; }

    friend std::ostream& operator<<(std::ostream& os, const Money& m) {
        long long a = m.paise < 0 ? -m.paise : m.paise;
        os << "Rs " << (m.paise < 0 ? "-" : "") << a / 100 << '.'
           << std::setfill('0') << std::setw(2) << a % 100 << std::setfill(' ');
        return os;
    }
};
int main() {
    Money a(120, 75), b(79, 25);
    Money c = a + b;
    std::cout << c << '\n' << std::boolalpha << (c == Money(200)) << '\n';

    // Added test: paise carry into rupees (Rs 0.75 + Rs 0.50)
    Money d = Money(0, 75) + Money(0, 50);
    std::cout << d << '\n';          // expected Rs 1.25
}

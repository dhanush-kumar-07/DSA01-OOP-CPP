// Task 3.4: compile twice:  g++ ... (virtual)   and   g++ ... -DVIRT=   (no virtual); compare output and sizeof
#include <iostream>
#include <string>
#ifndef VIRT
#define VIRT virtual
#endif
struct Person { std::string name = "n"; int id = 0; Person() { std::cout << "Person "; } };
struct Student : VIRT Person { double cgpa = 0; Student() { std::cout << "Student "; } };
struct Staff : VIRT Person { double salary = 0; Staff() { std::cout << "Staff "; } };
struct TeachingAssistant : Student, Staff { TeachingAssistant() { std::cout << "TA "; } };
int main() {
    TeachingAssistant t; std::cout << '\n';
    std::cout << "sizeof(Person)=" << sizeof(Person) << " sizeof(Student)=" << sizeof(Student)
              << " sizeof(Staff)=" << sizeof(Staff) << " sizeof(TeachingAssistant)=" << sizeof(t) << '\n';
}

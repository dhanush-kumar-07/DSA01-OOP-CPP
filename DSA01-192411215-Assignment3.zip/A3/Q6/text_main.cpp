// Q6 - tests for the Text class (run also with -fsanitize=address)
#include "Text.h"
#include <string>
int main() {
    Text a("Hello, "), b("SMS "), c("Gateway");
    Text::copies = 0;
    Text d = a + b + c;
    std::cout << "a + b + c = " << d << "  (copy-constructor calls: " << Text::copies << ")\n";

    Text e = d;                                   // copy constructor
    Text f; f = d;                                // copy assignment
    std::cout << "e = " << e << " | f = " << f << '\n';

    std::cout << std::boolalpha << "d == e: " << (d == e) << ", d != Text(\"x\"): " << (d != Text("x")) << '\n';

    d = d;                                        // self-assignment
    std::cout << "after d = d -> " << d << '\n';

    Text empty;
    std::cout << "empty message length: " << empty.length() << ", empty + a = '" << (empty + a) << "'\n";

    std::string longStr(5000, 'x');
    Text big(longStr.c_str());
    Text big2 = big + big;
    std::cout << "long message length: " << big.length() << " + " << big.length() << " = " << big2.length() << '\n';
}

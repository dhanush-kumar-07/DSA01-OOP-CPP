// Task B3 - virtual vs switch vs std::variant, and return codes vs exceptions vs optional.
// Build:  g++ -std=c++17 -O2 -Wall -Wextra B3_benchmark.cpp -o b3
// Run:    ./b3            (up to 10,000,000 bills; needs ~1 GB RAM)
//         ./b3 2000000    (custom maximum n)
// Do NOT combine with -fsanitize=address when timing.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <memory>
#include <optional>
#include <random>
#include <stdexcept>
#include <variant>
#include <vector>

using Clock = std::chrono::steady_clock;

// ---------- deterministic data generator ----------
struct Rec { int type; double a, b, c; };     // "one struct with a type field"
static inline std::uint64_t nextRand(std::uint64_t& s)
{
    s = s * 6364136223846793005ULL + 1442695040888963407ULL;
    return s >> 33;
}
static Rec genRec(std::uint64_t& s)
{
    Rec r;
    r.type = int(nextRand(s) % 4);
    r.a = double(1 + nextRand(s) % 1000);
    r.b = double(1 + nextRand(s) % 1000);
    r.c = double(1 + nextRand(s) % 1000);
    return r;
}

// ---------- (a) virtual functions ----------
struct VBill { virtual ~VBill() = default; virtual double total() const noexcept = 0; };
struct VOP : VBill { double c, t;      VOP(double c_, double t_) : c(c_), t(t_) {}              double total() const noexcept override { return c + t; } };
struct VIP : VBill { double d, r, x;   VIP(double d_, double r_, double x_) : d(d_), r(r_), x(x_) {} double total() const noexcept override { return d * r + x; } };
struct VDC : VBill { double p;         explicit VDC(double p_) : p(p_) {}                       double total() const noexcept override { return p; } };
struct VER : VBill { double b, h, r;   VER(double b_, double h_, double r_) : b(b_), h(h_), r(r_) {} double total() const noexcept override { return b + h * r; } };

static std::unique_ptr<VBill> makeV(const Rec& r)
{
    switch (r.type) {
        case 0:  return std::make_unique<VOP>(r.a, r.b);
        case 1:  return std::make_unique<VIP>(r.a, r.b, r.c);
        case 2:  return std::make_unique<VDC>(r.a);
        default: return std::make_unique<VER>(r.a, r.b, r.c);
    }
}

// ---------- (b) struct + switch ----------
static inline double totalSwitch(const Rec& r) noexcept
{
    switch (r.type) {
        case 0:  return r.a + r.b;
        case 1:  return r.a * r.b + r.c;
        case 2:  return r.a;
        default: return r.a + r.b * r.c;
    }
}

// ---------- (c) std::variant + std::visit ----------
struct POP { double c, t;    double total() const noexcept { return c + t; } };
struct PIP { double d, r, x; double total() const noexcept { return d * r + x; } };
struct PDC { double p;       double total() const noexcept { return p; } };
struct PER { double b, h, r; double total() const noexcept { return b + h * r; } };
using Var = std::variant<POP, PIP, PDC, PER>;

static Var makeVar(const Rec& r)
{
    switch (r.type) {
        case 0:  return POP{r.a, r.b};
        case 1:  return PIP{r.a, r.b, r.c};
        case 2:  return PDC{r.a};
        default: return PER{r.a, r.b, r.c};
    }
}

template <class F>
static double bestMs(int reps, F f, double& result)
{
    double best = 1e300;
    for (int i = 0; i < reps; ++i) {
        auto t0 = Clock::now();
        result = f();
        auto t1 = Clock::now();
        best = std::min(best, std::chrono::duration<double, std::milli>(t1 - t0).count());
    }
    return best;
}

// ---------- B3.1 correctness on 10 bills ----------
static void correctness()
{
    std::cout << "=== B3.1 Correctness on 10 bills ===\n";
    std::uint64_t s = 12345;
    std::vector<Rec> recs; std::vector<std::unique_ptr<VBill>> vs; std::vector<Var> vars;
    for (int i = 0; i < 10; ++i) { recs.push_back(genRec(s)); vs.push_back(makeV(recs.back())); vars.push_back(makeVar(recs.back())); }
    double sv = 0, ss = 0, sa = 0;
    for (int i = 0; i < 10; ++i) {
        double a = vs[i]->total(), b = totalSwitch(recs[i]);
        double c = std::visit([](const auto& x) { return x.total(); }, vars[i]);
        std::cout << "bill " << i << " type " << recs[i].type << ": virtual=" << a << " switch=" << b << " variant=" << c
                  << ((a == b && b == c) ? "  OK\n" : "  MISMATCH\n");
        sv += a; ss += b; sa += c;
    }
    std::cout << "sum virtual=" << sv << " switch=" << ss << " variant=" << sa
              << ((sv == ss && ss == sa) ? "  -> all agree\n\n" : "  -> DISAGREE\n\n");
}

// ---------- B3.2 scale ----------
static void scale(std::size_t maxN)
{
    std::cout << "=== B3.2 / alt: time to total n bills (-O2), best of reps, ms ===\n";
    std::cout << "sizeof(Rec)=" << sizeof(Rec) << "  sizeof(VIP)=" << sizeof(VIP)
              << "  sizeof(Var)=" << sizeof(Var) << "  sizeof(unique_ptr)=" << sizeof(std::unique_ptr<VBill>) << "\n";
    std::cout << std::setw(12) << "n" << std::setw(12) << "switch" << std::setw(12) << "virtual" << std::setw(12) << "variant" << "\n";
    for (std::size_t n : {std::size_t(1000), std::size_t(1000000), std::size_t(10000000)}) {
        if (n > maxN) break;
        int reps = n >= 10000000 ? 3 : (n >= 1000000 ? 5 : 2000);
        double rs = 0, rv = 0, ra = 0, tS, tV, tA;
        {
            std::uint64_t s = 99; std::vector<Rec> v; v.reserve(n);
            for (std::size_t i = 0; i < n; ++i) v.push_back(genRec(s));
            tS = bestMs(reps, [&] { double t = 0; for (const Rec& r : v) t += totalSwitch(r); return t; }, rs);
        }
        {
            std::uint64_t s = 99; std::vector<std::unique_ptr<VBill>> v; v.reserve(n);
            for (std::size_t i = 0; i < n; ++i) v.push_back(makeV(genRec(s)));
            tV = bestMs(reps, [&] { double t = 0; for (const auto& b : v) t += b->total(); return t; }, rv);
        }
        {
            std::uint64_t s = 99; std::vector<Var> v; v.reserve(n);
            for (std::size_t i = 0; i < n; ++i) v.push_back(makeVar(genRec(s)));
            tA = bestMs(reps, [&] { double t = 0; for (const auto& b : v) t += std::visit([](const auto& x) { return x.total(); }, b); return t; }, ra);
        }
        std::cout << std::setw(12) << n << std::fixed << std::setprecision(3)
                  << std::setw(12) << tS << std::setw(12) << tV << std::setw(12) << tA
                  << ((rs == rv && rv == ra) ? "" : "   (sums differ!)") << "\n";
    }
    std::cout << "\n";
}

// ---------- B3.3 cost of exceptions ----------
enum class Status { Ok, Negative, TooLarge };
static Status validateRC(double x) noexcept { return x < 0 ? Status::Negative : (x > 1e6 ? Status::TooLarge : Status::Ok); }
static void validateEx(double x)
{
    if (x < 0) throw std::invalid_argument("negative");
    if (x > 1e6) throw std::out_of_range("too large");
}
static std::optional<double> validateOpt(double x) noexcept
{
    if (x < 0 || x > 1e6) return std::nullopt;
    return x;
}

static void errors(std::size_t n)
{
    std::cout << "=== B3.3 Validate " << n << " bills: return codes vs exceptions vs optional (ms) ===\n";
    std::cout << std::setw(10) << "invalid%" << std::setw(14) << "return-code" << std::setw(14) << "exception" << std::setw(14) << "optional" << std::setw(14) << "ex/rc ratio\n";
    for (double pct : {0.0, 1.0, 50.0}) {
        std::vector<double> in(n);
        std::mt19937_64 g(7);
        std::uniform_real_distribution<double> u(0, 100);
        for (double& x : in) { double r = u(g); x = r < pct ? (u(g) < 50 ? -1.0 : 2e6) : 100.0; }

        double r1 = 0, r2 = 0, r3 = 0;
        double t1 = bestMs(3, [&] { double bad = 0; for (double x : in) if (validateRC(x) != Status::Ok) ++bad; return bad; }, r1);
        double t2 = bestMs(3, [&] { double bad = 0; for (double x : in) { try { validateEx(x); } catch (const std::exception&) { ++bad; } } return bad; }, r2);
        double t3 = bestMs(3, [&] { double bad = 0; for (double x : in) if (!validateOpt(x)) ++bad; return bad; }, r3);
        std::cout << std::fixed << std::setprecision(3) << std::setw(10) << pct << std::setw(14) << t1 << std::setw(14) << t2
                  << std::setw(14) << t3 << std::setw(14) << (t2 / (t1 > 0 ? t1 : 1e-9))
                  << ((r1 == r2 && r2 == r3) ? "" : "  (counts differ!)") << "\n";
    }
    std::cout << "\n";
}

int main(int argc, char** argv)
{
    std::size_t maxN = argc > 1 ? std::strtoull(argv[1], nullptr, 10) : 10000000;
    correctness();
    scale(maxN);
    errors(1000000);
    return 0;
}

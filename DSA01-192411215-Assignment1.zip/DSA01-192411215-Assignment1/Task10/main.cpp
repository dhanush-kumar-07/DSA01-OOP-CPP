// Task 10 - Expectation vs execution: double rupees vs integer paise vs int overflow
#include <chrono>
#include <climits>
#include <cmath>
#include <iomanip>
#include <iostream>

int main()
{
    // discounted / concession fares in paise (examples that are NOT multiples of 10 paise)
    const long long fares[] = {1000, 2000, 3600, 1250, 630, 990};
    const int K = 6;
    long long ns[] = {20000, 500000, 3000000};

    std::cout << std::setw(10) << "journeys" << std::setw(18) << "paise total" << std::setw(22) << "double total (Rs)"
              << std::setw(16) << "difference(Rs)" << std::setw(16) << "int total" << std::setw(8) << "ovf?" << '\n';
    for (long long n : ns) {
        long long paise = 0; double rupees = 0.0; unsigned int wrap32 = 0; float fl = 0.0f;
        for (long long i = 0; i < n; ++i) {
            long long f = fares[i % K];
            paise += f;
            rupees += static_cast<double>(f) / 100.0;
            wrap32 += static_cast<unsigned int>(f);          // behaves like a 32-bit int total
            fl += static_cast<float>(f) / 100.0f;
        }
        double exact = static_cast<double>(paise) / 100.0;
        std::cout << std::setw(10) << n << std::setw(18) << paise << std::setw(22) << std::fixed << std::setprecision(6) << rupees
                  << std::setw(16) << std::setprecision(9) << std::fabs(rupees - exact)
                  << std::setw(16) << static_cast<int>(wrap32) << std::setw(8) << (paise > INT_MAX ? "YES" : "no") << '\n';
        std::cout << "          float total (Rs) = " << std::setprecision(2) << fl << "  error " << std::fabs(fl - exact) << '\n';
    }

    // time per addition
    const long long N = 50000000;
    auto t0 = std::chrono::steady_clock::now();
    long long ls = 0; for (long long i = 0; i < N; ++i) ls += fares[i % K];
    auto t1 = std::chrono::steady_clock::now();
    double ds = 0; for (long long i = 0; i < N; ++i) ds += static_cast<double>(fares[i % K]) / 100.0;
    auto t2 = std::chrono::steady_clock::now();
    std::cout << std::defaultfloat << "\nlong long add: " << std::chrono::duration<double, std::nano>(t1 - t0).count() / N << " ns each"
              << "   double add: " << std::chrono::duration<double, std::nano>(t2 - t1).count() / N << " ns each"
              << "   (checksums " << ls << ", " << ds << ")\n";
    std::cout << "Memory per accumulator: int 4 bytes, long long 8, double 8, float 4.\n";
}

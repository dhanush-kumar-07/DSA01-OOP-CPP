// Task 5 - Peak check, surcharge, concession expressions; lookup-table alternative
#include <iostream>

bool isPeakReadable(int hour) { return (hour >= 8 && hour < 10) || (hour >= 17 && hour < 20); }
// same result: && binds tighter than ||, but harder to read (and -Wall warns about it)
bool isPeakNoBrackets(int hour) { return (hour >= 8 && hour < 10) || (hour >= 17 && hour < 20); }

constexpr bool PEAK[24] = {false,false,false,false,false,false,false,false, // 0-7
                           true, true,                                      // 8,9
                           false,false,false,false,false,false,false,       // 10-16
                           true, true, true,                                // 17,18,19
                           false,false,false,false};                        // 20-23
bool isPeakTable(int hour) { return PEAK[hour]; }

int main()
{
    int checks[] = {7, 8, 9, 10, 16, 17, 19, 20, 23};
    std::cout << "hour  readable  table\n";
    bool allSame = true;
    for (int h : checks) {
        std::cout << "  " << h << (h < 10 ? " " : "") << "      " << isPeakReadable(h) << "        " << isPeakTable(h) << '\n';
        if (isPeakReadable(h) != isPeakTable(h) || isPeakReadable(h) != isPeakNoBrackets(h)) allSame = false;
    }
    std::cout << "All versions agree: " << (allSame ? "yes" : "NO") << '\n';

    long long fare = 3000;
    bool peak = isPeakReadable(17), student = true;
    fare += peak ? fare * 20 / 100 : 0;       // ?: has lower precedence than * / +, so this reads as fare += (peak ? ... : 0)
    fare -= student ? fare * 50 / 100 : 0;
    std::cout << "Outer, 17:00, student fare = " << fare << " paise\n";

    int i = 5;
    int a = i++;   // a = 5, i = 6 (post-increment returns the old value)
    int b = ++i;   // i = 7, b = 7 (pre-increment returns the new value)
    std::cout << "a=" << a << " b=" << b << " i=" << i << '\n';
    // i = i++;  // mistake: modifies i twice in one expression, pointless and confusing
}

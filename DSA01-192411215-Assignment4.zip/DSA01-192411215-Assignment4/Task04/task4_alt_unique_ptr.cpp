// Task 4 Alternative: std::vector<std::unique_ptr<Account>>
#include <iostream>
#include <memory>
#include <vector>
class Account {
public:
    virtual ~Account() = default;       // STILL required: unique_ptr<Account> deletes via Account*
    virtual double rate() const { return 3.5; }
};
class SeniorAccount : public Account {
    std::unique_ptr<double[]> history = std::make_unique<double[]>(100);   // no manual delete[]
public:
    double rate() const override { return 4.0; }
};
int main() {
    std::vector<std::unique_ptr<Account>> v;
    v.push_back(std::make_unique<Account>());
    v.push_back(std::make_unique<SeniorAccount>());
    for (const auto& a : v) std::cout << a->rate() << '\n';
    // std::vector<Account> w; w.push_back(SeniorAccount());  // slicing would still be possible with values
    // vector<unique_ptr> cannot be copied, but forgetting 'virtual' (defect 1) or the virtual dtor (defect 2) still bites.
}   // all objects released automatically

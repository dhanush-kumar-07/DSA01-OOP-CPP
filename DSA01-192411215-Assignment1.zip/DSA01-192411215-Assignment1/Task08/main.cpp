// Task 8 - Safe input with cin (fail / clear / ignore) and formatted output
// Input order: starting balance (Rs), number of journeys, then per journey: zone(0-2) hour(0-23)
// Run:  ./main < input.txt     or type values yourself.
#include <iomanip>
#include <iostream>
#include <limits>

constexpr int BASE_PAISE[] = {1000, 2000, 3000};

bool readInt(const char* prompt, int lo, int hi, int& out)
{
    while (true) {
        std::cout << prompt;
        if (!(std::cin >> out)) {
            if (std::cin.eof()) return false;                       // input finished
            std::cin.clear();                                       // clear the fail state
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');  // discard bad line
            std::cout << "\n  Invalid input: please type a number.\n";
            continue;
        }
        if (out < lo || out > hi) { std::cout << "\n  Out of range (" << lo << ".." << hi << ").\n"; continue; }
        std::cout << out << '\n';
        return true;
    }
}

void printMoney(long long paise)
{
    std::cout << "Rs " << std::setw(6) << paise / 100 << '.' << std::setw(2) << std::setfill('0') << paise % 100 << std::setfill(' ');
}

int main()
{
    int rupees = 0, n = 0;
    if (!readInt("Starting balance (Rs 50..100000): ", 50, 100000, rupees)) return 1;
    if (!readInt("Number of journeys (1..20): ", 1, 20, n)) return 1;
    long long balance = rupees * 100LL;

    std::cout << "\n" << std::left << std::setw(4) << "No" << std::setw(6) << "Zone" << std::setw(6) << "Hour"
              << std::setw(10) << "Type" << std::setw(14) << "Fare" << std::setw(10) << "Result" << "Balance\n" << std::right;
    for (int i = 1; i <= n; ++i) {
        int zone, hour;
        if (!readInt("Zone (0 Inner,1 Middle,2 Outer): ", 0, 2, zone)) break;
        if (!readInt("Hour (0-23): ", 0, 23, hour)) break;
        bool peak = (hour >= 8 && hour < 10) || (hour >= 17 && hour < 20);
        long long f = BASE_PAISE[zone];
        if (peak) f += f * 20 / 100;
        bool ok = balance - f >= 5000;
        if (ok) balance -= f;
        std::cout << std::left << std::setw(4) << i << std::setw(6) << zone << std::setw(6) << hour
                  << std::setw(10) << (peak ? "peak" : "off-peak") << std::right;
        printMoney(f);
        std::cout << "  " << std::left << std::setw(8) << (ok ? "PAID" : "DENIED") << std::right;
        printMoney(balance);
        std::cout << '\n';
    }
    std::cout << std::fixed << std::setprecision(2) << "Closing balance: Rs " << balance / 100.0 << '\n';
}

// Task 12 - Redesign: 4th zone (Airport Rs 60), 10% weekend discount (not combined with peak surcharge),
// monthly pass (unlimited journeys in two chosen zones). Design: fare table indexed by zone + separate discount rule + Pass class.
#include <iomanip>
#include <iostream>

enum class Zone { Inner, Middle, Outer, Airport, COUNT };           // adding a zone = one enum value + one table row
enum class Rider { Regular, Student, Senior };

constexpr long long BASE_PAISE[] = {1000, 2000, 3000, 6000};
static_assert(sizeof(BASE_PAISE) / sizeof(BASE_PAISE[0]) == static_cast<std::size_t>(Zone::COUNT), "one fare per zone");
constexpr int PEAK_PERCENT = 20;
constexpr int WEEKEND_DISCOUNT_PERCENT = 10;
constexpr int CONCESSION_PERCENT = 50;
constexpr long long MIN_BALANCE_PAISE = 5000;

constexpr bool isPeak(int hour) { return (hour >= 8 && hour < 10) || (hour >= 17 && hour < 20); }

// separate rule: weekend discount REPLACES the peak surcharge
long long timeAdjusted(long long base, bool peak, bool weekend)
{
    if (weekend) return base - base * WEEKEND_DISCOUNT_PERCENT / 100;
    return peak ? base + base * PEAK_PERCENT / 100 : base;
}

class Pass {
public:
    Pass(Zone a, Zone b) : a_(a), b_(b) {}
    bool covers(Zone z) const { return z == a_ || z == b_; }
private:
    Zone a_, b_;
};

class SmartCard {
public:
    explicit SmartCard(long long p) : balance_(p) {}
    bool canTravel(long long f) const { return f >= 0 && balance_ - f >= MIN_BALANCE_PAISE; }
    bool deduct(long long f) { if (!canTravel(f)) return false; balance_ -= f; return true; }
    long long balance() const { return balance_; }
    void attachPass(const Pass& p) { pass_ = p; hasPass_ = true; }
    bool passCovers(Zone z) const { return hasPass_ && pass_.covers(z); }
private:
    long long balance_;
    Pass pass_{Zone::Inner, Zone::Inner};
    bool hasPass_ = false;
};

long long fare(const SmartCard& card, Zone z, int hour, bool weekend, Rider r)
{
    if (card.passCovers(z)) return 0;                                  // pass: unlimited journeys in its two zones
    long long f = timeAdjusted(BASE_PAISE[static_cast<int>(z)], isPeak(hour), weekend);
    if (r != Rider::Regular) f -= f * CONCESSION_PERCENT / 100;
    return f;
}

int main()
{
    struct T { const char* name; Zone z; int hour; bool weekend; Rider r; bool pass; long long expected; } tests[] = {
        {"Airport weekday off-peak", Zone::Airport, 12, false, Rider::Regular, false, 6000},
        {"Airport weekday peak",     Zone::Airport, 9,  false, Rider::Regular, false, 7200},
        {"Airport weekend peak",     Zone::Airport, 9,  true,  Rider::Regular, false, 5400},   // discount, no surcharge
        {"Inner weekend off-peak",   Zone::Inner,   12, true,  Rider::Regular, false, 900},
        {"Middle weekend peak",      Zone::Middle,  18, true,  Rider::Regular, false, 1800},
        {"Outer weekday peak student",Zone::Outer,  17, false, Rider::Student, false, 1800},
        {"Pass: Inner covered",      Zone::Inner,   9,  false, Rider::Regular, true,  0},
        {"Pass: Middle covered",     Zone::Middle,  12, true,  Rider::Regular, true,  0},
        {"Pass: Outer NOT covered",  Zone::Outer,   12, false, Rider::Regular, true,  3000},
        {"Pass: Airport NOT covered",Zone::Airport, 12, false, Rider::Regular, true,  6000},
    };
    int pass = 0, total = 0;
    std::cout << std::left << std::setw(28) << "Test" << std::setw(10) << "Expected" << std::setw(10) << "Actual" << "Result\n" << std::right;
    for (const T& t : tests) {
        SmartCard card(20000);
        if (t.pass) card.attachPass(Pass(Zone::Inner, Zone::Middle));
        long long actual = fare(card, t.z, t.hour, t.weekend, t.r);
        bool ok = actual == t.expected;
        ++total; pass += ok;
        std::cout << std::left << std::setw(28) << t.name << std::setw(10) << t.expected << std::setw(10) << actual << (ok ? "PASS" : "FAIL") << '\n' << std::right;
    }
    // balance rule still holds with the new Airport fare
    SmartCard c(10000);
    bool d1 = c.deduct(fare(c, Zone::Airport, 12, false, Rider::Regular));   // 10000-6000=4000 < 5000 -> denied
    bool ok = !d1 && c.balance() == 10000;
    ++total; pass += ok;
    std::cout << "Airport on Rs 100 balance denied, balance unchanged: " << (ok ? "PASS" : "FAIL") << '\n';
    std::cout << "\nSummary: " << pass << " / " << total << " tests passed\n";
    return pass == total ? 0 : 1;
}

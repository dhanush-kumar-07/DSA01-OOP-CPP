# DSA01-192411215-Assignment1 - Namma Metro Smart-Card Fare System (C++)

- **Name:** Dhanush Kumar R
- **Register number:** 192411215
- **Compiler:** g++ (version: run `g++ --version` and paste it here, e.g. g++ 13)
- **Compile command used for every program:** `g++ -std=c++17 -Wall -Wextra <file>.cpp -o <name>`

## How to run (VS Code, Windows)
1. Open this folder in VS Code (File > Open Folder).
2. Open a `.cpp` file, press **Ctrl+Shift+B** (build), then run the .exe from the terminal, e.g.
   `cd Task06` then `.\complete_code.exe`
3. Or run everything at once: `powershell -ExecutionPolicy Bypass -File .\run_all.ps1` (outputs saved in `outputs/`).
4. Task 8 needs input: `Get-Content input.txt | .\main.exe` (or type the values yourself). `getline_version` uses `input_lines.txt`.
5. Task 11 must be run from inside `Task11` so it can find `fares.cfg`.

## Tasks
| Task | Files | Result |
|---|---|---|
| 1 OO analysis | `Task01/main.cpp` | Objects, encapsulation, polymorphism; rule R1 holds |
| 2 Tokens/constants | `Task02/main.cpp` | Macro bug `DOUBLE_IT(1+2)=5`; enum class needs cast |
| 3 Data types | `Task03/main.cpp` | sizeof/ranges; double error grows with n; int overflows at 3M journeys |
| 4 Implicit conversions | `Task04/predict.cpp`, `fixed.cpp` | Prediction vs actual; sign-compare warning; fixed with casts/braces |
| 5 Precedence | `Task05/predict.cpp`, `peak_check.cpp` | Prediction vs actual; table lookup equals expression |
| 6 Control structures | `Task06/complete_code.cpp`, `peak_boundary.cpp`, `pseudocode.txt` | Matches expected output; 10:00 and 20:00 are off-peak |
| 7 Procedural vs OOP | `Task07/*.cpp` | Procedural/public balance can go negative; OOP cannot |
| 8 Input/output | `Task08/main.cpp`, `getline_version.cpp` | Recovers from letters and out-of-range input |
| 9 Implementation & tests | `Task09/main.cpp` | 22/22 tests pass |
| 10 Expectation vs execution | `Task10/main.cpp` | Double drifts, int overflows at 3M, long long exact |
| 11 Final design | `Task11/main.cpp`, `fares.cfg` | constexpr defaults + config file override |
| 12 Design challenge | `Task12/main.cpp`, `analysis.md` | MODIFY: zone table, discount rule, Pass class; 11/11 tests pass |

## Assumptions
Concession = 50% for students and seniors, applied after the peak surcharge; peak hours use start-inclusive, end-exclusive (8-10 and 17-20); weekend discount replaces the peak surcharge.

## Predictions for Tasks 4 and 5 (write yours BEFORE running)
Task 4: `3 3.5` / `C 68` / `1 true` / `s >= u`
Task 5: `11 16` / `9 6 4` / `6 4` / `3 1 -3 -1` / `18`

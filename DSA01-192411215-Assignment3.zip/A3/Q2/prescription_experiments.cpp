// Q2 experiments: copy counting, timing for 10 / 1,000 / 100,000 medicines, self-assignment.
#include <chrono>
#include <iostream>
#include <string>
class Prescription {
    int n;
    std::string* medicines;
public:
    static int copies;
    explicit Prescription(int count) : n(count), medicines(new std::string[count]) {}
    Prescription(const Prescription& o) : n(o.n), medicines(new std::string[o.n]) {
        ++copies; std::cout << "  [copy ctor called]\n";
        for (int i = 0; i < n; ++i) medicines[i] = o.medicines[i];
    }
    Prescription& operator=(const Prescription& o) {
        if (this != &o) {
            std::string* f = new std::string[o.n];
            for (int i = 0; i < o.n; ++i) f[i] = o.medicines[i];
            delete[] medicines; medicines = f; n = o.n;
        }
        return *this;
    }
    ~Prescription() { delete[] medicines; }
    void set(int i, const std::string& m) { medicines[i] = m; }
    std::string get(int i) const { return medicines[i]; }
    int size() const { return n; }
};
int Prescription::copies = 0;

void byValue(Prescription p)           { std::cout << "  in byValue, size=" << p.size() << '\n'; }
void byConstRef(const Prescription& p) { std::cout << "  in byConstRef, size=" << p.size() << '\n'; }

int main() {
    Prescription p(3);
    p.set(0, "A"); p.set(1, "B"); p.set(2, "C");

    std::cout << "Pass by value:\n";      byValue(p);
    std::cout << "Pass by const ref:\n";  byConstRef(p);
    std::cout << "Total copies made: " << Prescription::copies << "\n\n";

    std::cout << "Self-assignment test (p = p):\n";
    p = p;
    std::cout << "  after p = p -> " << p.get(0) << ' ' << p.get(1) << ' ' << p.get(2) << " (still intact)\n\n";

    std::cout << "Copy timing:\n";
    for (int n : {10, 1000, 100000}) {
        Prescription big(n);
        for (int i = 0; i < n; ++i) big.set(i, "Medicine" + std::to_string(i));
        auto t0 = std::chrono::steady_clock::now();
        Prescription::copies = 0;
        Prescription copy(big);
        auto t1 = std::chrono::steady_clock::now();
        double us = std::chrono::duration<double, std::micro>(t1 - t0).count();
        std::cout << "  n = " << n << " -> " << us << " microseconds\n";
    }
}

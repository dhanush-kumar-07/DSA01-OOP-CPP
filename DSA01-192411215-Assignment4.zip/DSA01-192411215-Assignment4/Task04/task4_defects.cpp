// Task 4.1/4.2 - the DEFECTIVE program with evidence prints. Run also with -fsanitize=address
#include <iostream>
class Account {
public:
    double rate() const { return 3.5; }                 // not virtual  -> defect 1
    ~Account() { std::cout << "  ~Account\n"; }        // not virtual  -> defect 2
};
class SeniorAccount : public Account {
    double* history = new double[100];
public:
    SeniorAccount() { std::cout << "  SeniorAccount: history allocated\n"; }
    double rate() const { return 4.0; }
    ~SeniorAccount() { delete[] history; std::cout << "  ~SeniorAccount: history freed\n"; }
};
int main() {
    Account* accounts[2] = { new Account, new SeniorAccount };
    std::cout << "Rates through base pointers:\n";
    for (Account* a : accounts) std::cout << a->rate() << "\n";   // 3.5 and 3.5 (should be 3.5 and 4.0)
    std::cout << "Deleting through base pointers:\n";
    for (Account* a : accounts) delete a;                          // SeniorAccount dtor never runs
    std::cout << "Slicing:\n";
    {
        Account copy = SeniorAccount();                            // Senior part sliced off
        std::cout << "  copy.rate() = " << copy.rate() << "  (Senior data/behaviour lost)\n";
    }
}

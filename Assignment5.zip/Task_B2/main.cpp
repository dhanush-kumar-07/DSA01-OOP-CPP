// ===== TASK B2 - Engineer error conditions (run this ONE file) =====
// Build: g++ -std=c++17 -Wall -Wextra -fsanitize=address -g main.cpp -o b2 && ./b2
// Sections: (1) Predict the Output  (2) Complete the Code  (3) error injection  (4) std::optional alternative
// Write your prediction for section (1) BEFORE running!
#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <map>
#include <memory>
#include <new>
#include <optional>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#include <functional>

// ---------------- Exception hierarchy (A4.1) ----------------
class BillingError : public std::runtime_error {
public:
    using std::runtime_error::runtime_error;
};
class NegativeChargeError : public BillingError { public: using BillingError::BillingError; };
class ClaimError          : public BillingError { public: using BillingError::BillingError; };
class UnknownPackageError : public BillingError { public: using BillingError::BillingError; };
class MissingRecordError  : public BillingError { public: using BillingError::BillingError; };
// std::bad_alloc is left as the standard exception for allocation failure.

inline void requireNonNegative(double v, const char* what)
{
    if (v < 0) throw NegativeChargeError(std::string("negative ") + what);
}

inline double packagePrice(const std::string& code)
{
    static const std::map<std::string, double> table{
        {"CATARACT", 25000}, {"HERNIA", 45000}, {"APPENDIX", 38000}};
    auto it = table.find(code);
    if (it == table.end()) throw UnknownPackageError("unknown package: " + code);
    return it->second;
}

// ---------------- Patient records ----------------
class PatientRegistry {
    std::set<std::string> names;
public:
    void add(const std::string& n) { names.insert(n); }
    void require(const std::string& n) const
    {
        if (!names.count(n)) throw MissingRecordError("no patient record for " + n);
    }
};

// ---------------- Abstract Bill (A1) ----------------
class Bill {
protected:
    std::string patient;
public:
    explicit Bill(std::string p) : patient(std::move(p)) {}
    Bill(const Bill&) = delete;
    Bill& operator=(const Bill&) = delete;
    virtual ~Bill() = default;                      // virtual destructor (A2.3)

    virtual double total() const noexcept = 0;      // pure virtual
    virtual std::string type() const = 0;           // pure virtual

    const std::string& patientName() const noexcept { return patient; }
    void print() const
    {
        std::cout << type() << ' ' << patient << ": " << total() << '\n';
    }
};

class OutPatientBill : public Bill {
    double consultation, tests;
public:
    OutPatientBill(const std::string& p, double c, double t)
        : Bill(p), consultation(c), tests(t)
    {
        requireNonNegative(c, "consultation charge");
        requireNonNegative(t, "test charge");
    }
    double total() const noexcept override { return consultation + tests; }
    std::string type() const override { return "OP"; }
};

class InPatientBill : public Bill {
    int days;
    double perDay, procedures, medicines;
public:
    InPatientBill(const std::string& p, int d, double rate, double proc, double med)
        : Bill(p), days(d), perDay(rate), procedures(proc), medicines(med)
    {
        if (d < 0) throw NegativeChargeError("negative number of days");
        requireNonNegative(rate, "room rate");
        requireNonNegative(proc, "procedure charge");
        requireNonNegative(med, "medicine charge");
    }
    double total() const noexcept override { return days * perDay + procedures + medicines; }
    std::string type() const override { return "IP"; }
};

class DayCareBill : public Bill {
    double price;
public:
    DayCareBill(const std::string& p, const std::string& packageCode)
        : Bill(p), price(packagePrice(packageCode)) {}   // may throw UnknownPackageError
    double total() const noexcept override { return price; }
    std::string type() const override { return "DC"; }
};

class EmergencyBill : public Bill {
    double base, hours, ratePerHour;
public:
    EmergencyBill(const std::string& p, double b, double h, double r)
        : Bill(p), base(b), hours(h), ratePerHour(r)
    {
        requireNonNegative(b, "base charge");
        requireNonNegative(h, "hours");
        requireNonNegative(r, "hourly rate");
    }
    double total() const noexcept override { return base + hours * ratePerHour; }
    std::string type() const override { return "ER"; }
};

// ---------------- Abstract Payer (A3) ----------------
class Payer {
public:
    virtual ~Payer() = default;
    virtual double amountCovered(const Bill& b) const = 0;
    virtual std::string name() const = 0;
};

class SelfPay : public Payer {
public:
    double amountCovered(const Bill&) const override { return 0.0; }
    std::string name() const override { return "SelfPay"; }
};

class Insurance : public Payer {
    double limit, copayPct;
public:
    Insurance(double coverLimit, double copayPercent)
        : limit(coverLimit), copayPct(copayPercent)
    {
        if (coverLimit < 0 || copayPercent < 0 || copayPercent > 100)
            throw std::invalid_argument("bad insurance policy");
    }
    double amountCovered(const Bill& b) const override
    {
        double t = b.total();
        if (t > limit) throw ClaimError("claim " + std::to_string(t) + " exceeds cover " + std::to_string(limit));
        return t * (1.0 - copayPct / 100.0);
    }
    std::string name() const override { return "Insurance(" + std::to_string((int)copayPct) + "% co-pay)"; }
};

class GovernmentScheme : public Payer {
    std::map<std::string, double> rates;   // fixed package rate per bill type
public:
    static std::map<std::string, double> defaultRates()
    {
        return {{"OP", 1000}, {"IP", 30000}, {"DC", 25000}, {"ER", 5000}};
    }
    explicit GovernmentScheme(std::map<std::string, double> r = defaultRates()) : rates(std::move(r)) {}
    double amountCovered(const Bill& b) const override
    {
        auto it = rates.find(b.type());
        if (it == rates.end()) throw UnknownPackageError("no package rate for bill type " + b.type());
        return std::min(b.total(), it->second);
    }
    std::string name() const override { return "GovScheme"; }
};

struct Settlement { double total, covered, patientPays; };

inline Settlement settle(const Bill& b, const Payer& p)
{
    double c = p.amountCovered(b);          // may throw ClaimError / UnknownPackageError
    return {b.total(), c, b.total() - c};
}

// ====================== (1) Predict the Output ======================
namespace predict {
void validate(double amount)
{
    if (amount < 0) throw std::invalid_argument("negative");
    if (amount > 1e6) throw std::out_of_range("too large");
    std::cout << "ok ";
}
void process(double amount)
{
    try { validate(amount); }
    catch (const std::out_of_range& e) { std::cout << "[log " << e.what() << "] "; throw; }
}
void run()
{
    for (double a : {100.0, -5.0, 2e6}) {
        try { process(a); std::cout << "done "; }
        catch (const std::exception& e) { std::cout << "caught " << e.what() << ' '; }
    }
    std::cout << '\n';
}
}

// ====================== (2) Complete the Code (TODO 1, 2 filled) ======================
namespace complete {
class ClaimError : public std::runtime_error { public: using std::runtime_error::runtime_error; };
double approve(double billed, double cover)
{
    // TODO 1
    if (billed < 0 || cover < 0) throw std::invalid_argument("negative amount");
    if (billed > cover) throw ClaimError("exceeds cover");
    return billed;
}
double settle(double billed, double cover)
{
    try { return approve(billed, cover); }
    catch (const ClaimError& e) {
        // TODO 2
        std::cout << "audit: " << e.what() << '\n';
        throw;       // rethrows the SAME object. Experiment: "throw e;" copies e into a NEW exception of its
                     // static type. Change the handler to catch (const std::runtime_error& e) and use "throw e;"
                     // to see the type get sliced so main's catch (ClaimError) no longer matches.
    }
}
void run()
{
    double cases[][2] = {{40000, 50000}, {60000, 50000}, {-1, 50000}};
    for (auto& c : cases) {
        try { double paid = settle(c[0], c[1]); std::cout << "approved " << paid << '\n'; }
        catch (const ClaimError& e)     { std::cout << "claim rejected: " << e.what() << '\n'; }
        catch (const std::exception& e) { std::cout << "error: " << e.what() << '\n'; }
    }
    // Expected: approved 40000 / audit: exceeds cover / claim rejected: exceeds cover / error: negative amount
}
}

// ====================== (3) Error injection ======================
namespace errors {
struct Tracker {                       // RAII object: proves stack unwinding
    std::string n;
    explicit Tracker(std::string s) : n(std::move(s)) { std::cout << "   +" << n << '\n'; }
    ~Tracker() { std::cout << "   ~" << n << " destroyed\n"; }
};
void runTest(const std::string& label, const std::function<void()>& body)
{
    std::cout << "[" << label << "]\n";
    try { Tracker t("tracker-in-" + label); body(); std::cout << "   no error\n"; }
    catch (const ClaimError& e)            { std::cout << "   ClaimError: " << e.what() << '\n'; }
    catch (const BillingError& e)          { std::cout << "   BillingError: " << e.what() << '\n'; }
    catch (const std::bad_alloc& e)        { std::cout << "   bad_alloc: " << e.what() << '\n'; }
    catch (const std::invalid_argument& e) { std::cout << "   invalid_argument: " << e.what() << '\n'; }
    catch (const std::out_of_range& e)     { std::cout << "   out_of_range: " << e.what() << '\n'; }
    catch (const std::exception& e)        { std::cout << "   std::exception: " << e.what() << '\n'; }
    catch (...)                            { std::cout << "   catch(...): unknown exception, program continues\n"; }
}
void run()
{
    PatientRegistry reg; reg.add("Ravi");
    runTest("negative-charge",   [] { OutPatientBill b("X", -100, 50); });
    runTest("claim-above-cover", [] { InPatientBill b("Meena", 3, 2500, 40000, 3000); settle(b, Insurance(10000, 20)); });
    runTest("unknown-package",   [] { DayCareBill b("Y", "BYPASS"); });
    runTest("missing-record",    [&] { reg.require("Ghost"); });
    runTest("stod-text",         [] { std::stod("abc"); });          // std::invalid_argument
    runTest("stod-overflow",     [] { std::stod("1e999"); });        // std::out_of_range
    runTest("bad_alloc",         [] {
#if defined(__SANITIZE_ADDRESS__)
        volatile std::size_t n = ~std::size_t(0) / 2;                // ASan aborts on a real huge malloc, so overflow instead
#else
        volatile std::size_t n = std::size_t(1) << 50;               // real bad_alloc
#endif
        double* p = new double[n]; p[0] = 1; delete[] p;
    });
    runTest("non-std-exception", [] { Tracker inner("inner-guard"); throw 42; });
    std::cout << "Program still running after all errors - no data lost.\n";
}
}

// ====================== (4) Alternative: std::optional ======================
namespace opt {
std::optional<double> approve(double billed, double cover)
{
    if (billed < 0 || cover < 0 || billed > cover) return std::nullopt;     // the reason is LOST
    return billed;
}
void run()
{
    for (double b : {40000.0, 60000.0, -1.0}) {
        auto r = approve(b, 50000);
        std::cout << b << " -> " << (r ? "approved " + std::to_string(*r) : std::string("rejected (but why?)")) << '\n';
    }
}
}

int main()
{
    std::cout << "##### (1) Predict the Output #####\n";   predict::run();
    std::cout << "\n##### (2) Complete the Code #####\n";   complete::run();
    std::cout << "\n##### (3) Error conditions #####\n";    errors::run();
    std::cout << "\n##### (4) std::optional alternative #####\n"; opt::run();
}

// Q6 - Growth Investigation: 10,000,000 calls, with/without inline, at -O0 and -O2
//   g++ -std=c++17 -O0 inline_benchmark.cpp -o bench_O0
//   g++ -std=c++17 -O2 inline_benchmark.cpp -o bench_O2
#include <iostream>
#include <chrono>
#include <cstdlib>

#if defined(_MSC_VER)
  #define NOINLINE __declspec(noinline)
#else
  #define NOINLINE __attribute__((noinline))
#endif

class Time;
NOINLINE int minutesNoInline(const Time& a, const Time& b);     // never inlined

class Time {
    int h, m;
public:
    Time(int hh, int mm) : h(hh), m(mm) {}
    int hour() const { return h; }
    int minute() const { return m; }
    int minutesTo(const Time& o) const { return std::abs((o.h * 60 + o.m) - (h * 60 + m)); }  // member
    friend inline int minutesInline(const Time& a, const Time& b);                              // friend, inline
    friend int minutesNoInline(const Time& a, const Time& b);                                   // friend, noinline
};
inline int minutesInline(const Time& a, const Time& b) { return std::abs((a.h * 60 + a.m) - (b.h * 60 + b.m)); }
NOINLINE int minutesNoInline(const Time& a, const Time& b) { return std::abs((a.h * 60 + a.m) - (b.h * 60 + b.m)); }
inline int minutesGetters(const Time& a, const Time& b) {                                       // public getters
    return std::abs((a.hour() * 60 + a.minute()) - (b.hour() * 60 + b.minute()));
}

template <class F>
void run(const char* name, F f) {
    const int N = 10000000;
    volatile long long sink = 0;
    long long sum = 0;
    auto t0 = std::chrono::steady_clock::now();
    for (int i = 0; i < N; ++i) {
        Time a(i % 24, i % 60), b((i * 7) % 24, (i * 13) % 60);
        sum += f(a, b);
    }
    auto t1 = std::chrono::steady_clock::now();
    sink = sum;
    double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
    std::cout << name << ": " << ms << " ms   (checksum " << sink << ")\n";
}

int main() {
    std::cout << "10,000,000 calls each\n";
    run("friend inline   ", [](const Time& a, const Time& b) { return minutesInline(a, b); });
    run("friend NOinline ", [](const Time& a, const Time& b) { return minutesNoInline(a, b); });
    run("member function ", [](const Time& a, const Time& b) { return a.minutesTo(b); });
    run("public getters  ", [](const Time& a, const Time& b) { return minutesGetters(a, b); });
}

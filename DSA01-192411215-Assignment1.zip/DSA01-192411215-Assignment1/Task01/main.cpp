// Task 1 - Object-oriented analysis of the Namma Metro fare problem
// Shows: objects (Passenger, SmartCard, Journey, Zone, FareTable), encapsulation,
// abstraction, inheritance and polymorphism (Concession), and the rules of a correct journey.
#include <iomanip>
#include <iostream>
#include <memory>
#include <string>

enum class Zone { Inner, Middle, Outer };

// Abstraction + inheritance + polymorphism: one interface, many concession kinds
class Concession {
public:
    virtual ~Concession() = default;
    virtual int percentOff() const = 0;
    virtual std::string name() const = 0;
};
class NoConcession : public Concession {
public:
    int percentOff() const override { return 0; }
    std::string name() const override { return "Regular"; }
};
class StudentConcession : public Concession {
public:
    int percentOff() const override { return 50; }
    std::string name() const override { return "Student"; }
};
class SeniorConcession : public Concession {
public:
    int percentOff() const override { return 50; }
    std::string name() const override { return "Senior"; }
};

// FareTable: owns the fare data and the fare behaviour (all values in integer paise)
class FareTable {
public:
    long long fare(Zone z, bool peak, const Concession& c) const {
        long long f = BASE[static_cast<int>(z)];
        if (peak) f += f * PEAK_PERCENT / 100;
        f -= f * c.percentOff() / 100;
        return f;
    }
private:
    static constexpr long long BASE[3] = {1000, 2000, 3000};
    static constexpr int PEAK_PERCENT = 20;
};

// SmartCard: encapsulates the balance so the "min Rs 50" rule cannot be broken from outside
class SmartCard {
public:
    explicit SmartCard(long long paise) : balance_(paise) {}
    bool canTravel(long long fare) const { return balance_ - fare >= MIN_BALANCE; }
    bool deduct(long long fare) {
        if (!canTravel(fare)) return false;
        balance_ -= fare;
        return true;
    }
    long long balance() const { return balance_; }
    static constexpr long long MIN_BALANCE = 5000;
private:
    long long balance_;
};

// Journey: zone + hour; knows whether it is peak
class Journey {
public:
    Journey(Zone z, int hour) : zone_(z), hour_(hour) {}
    Zone zone() const { return zone_; }
    int hour() const { return hour_; }
    bool isPeak() const { return (hour_ >= 8 && hour_ < 10) || (hour_ >= 17 && hour_ < 20); }
private:
    Zone zone_;
    int hour_;
};

// Passenger: has a concession type and a card
class Passenger {
public:
    Passenger(std::string n, std::unique_ptr<Concession> c, long long paise)
        : name_(std::move(n)), concession_(std::move(c)), card_(paise) {}
    std::string name_;
    std::unique_ptr<Concession> concession_;
    SmartCard card_;
};

int main()
{
    FareTable table;
    Passenger p("Asha", std::make_unique<StudentConcession>(), 10000);
    Journey js[] = {{Zone::Inner, 9}, {Zone::Outer, 17}, {Zone::Middle, 11}, {Zone::Outer, 12}};
    bool allRulesHold = true;

    std::cout << "Passenger: " << p.name_ << " (" << p.concession_->name() << ")\n";
    for (const Journey& j : js) {
        long long f = table.fare(j.zone(), j.isPeak(), *p.concession_);
        bool ok = p.card_.deduct(f);
        std::cout << "Hour " << std::setw(2) << j.hour() << (j.isPeak() ? " peak " : " off  ")
                  << "fare " << f / 100 << '.' << std::setw(2) << std::setfill('0') << f % 100
                  << std::setfill(' ') << (ok ? " paid  " : " DENIED") << " balance Rs "
                  << p.card_.balance() / 100 << '\n';
        if (p.card_.balance() < SmartCard::MIN_BALANCE) allRulesHold = false;  // Rule R1
    }
    std::cout << "Rule R1 (balance never below Rs 50): " << (allRulesHold ? "HOLDS" : "BROKEN") << '\n';
}

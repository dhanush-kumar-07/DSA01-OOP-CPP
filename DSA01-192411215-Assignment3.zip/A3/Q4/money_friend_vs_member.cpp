// Q4 alternative: member vs friend operator+ -> which allows 100 + m ?
// Compile as is: works. Compile with -DMEMBER_ONLY : "100 + m" fails (left operand 100 is an int, not a Money).
#include <iostream>
class Money {
    long long paise;
public:
    Money(long long rupees = 0, int p = 0) : paise(rupees * 100 + p) {}
    long long raw() const { return paise; }
#ifdef MEMBER_ONLY
    Money operator+(const Money& o) const { return Money(0, (int)(paise + o.paise)); }
#else
    friend Money operator+(const Money& a, const Money& b) { return Money(0, (int)(a.paise + b.paise)); }
#endif
};
int main() {
    Money m(5, 50);
    Money x = m + 100;        // works in both: 100 converts to Money for the argument
    Money y = 100 + m;        // works ONLY with the non-member/friend version
    std::cout << x.raw() << ' ' << y.raw() << '\n';
}

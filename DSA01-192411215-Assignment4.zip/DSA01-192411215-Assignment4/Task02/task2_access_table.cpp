// Task 2.4 - Access of Person's members inside derived classes (and from outside)
#include <iostream>
class Person { public: int pub = 1; protected: int prot = 2; private: int priv = 3;
public: int readPriv() const { return priv; } };

class StudentPub  : public    Person { public: void test() { std::cout << "public inh : pub=" << pub << " prot=" << prot << " priv=(not accessible)\n"; } };
class StudentProt : protected Person { public: void test() { std::cout << "protected  : pub=" << pub << " prot=" << prot << " priv=(not accessible)\n"; } };
class StudentPriv : private   Person { public: void test() { std::cout << "private    : pub=" << pub << " prot=" << prot << " priv=(not accessible)\n"; } };

int main() {
    StudentPub a; StudentProt b; StudentPriv c;
    a.test(); b.test(); c.test();
    std::cout << "outside, public inheritance: a.pub=" << a.pub << '\n';
    // std::cout << b.pub;   // ERROR: pub became protected in StudentProt
    // std::cout << c.pub;   // ERROR: pub became private in StudentPriv
    // std::cout << a.prot;  // ERROR: protected outside
    // Inside StudentPub::test(): priv -> ERROR (private to Person)
    // Uncomment any line above to see the compiler message for your report.
}

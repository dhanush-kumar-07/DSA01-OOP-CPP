// Q4 - Same class with a CIRCULAR BUFFER (start index): O(1) per transaction.
// Changing 10 -> 50 transactions needs only the single constant MAX.
#include <iostream>
#include <iomanip>

struct Transaction { char type; double amount; };

class SavingsAccount {
    static const int MAX = 10;          // <-- change to 50 for the "last 50" requirement
    int         accNo;
    double      balance;
    Transaction last[MAX];
    int         start;                  // index of the oldest transaction
    int         count;

    void record(char type, double amount) {
        if (count < MAX) {
            last[(start + count) % MAX] = {type, amount};
            ++count;
        } else {                        // overwrite oldest, move start
            last[start] = {type, amount};
            start = (start + 1) % MAX;
        }
    }
public:
    SavingsAccount(int no, double opening) : accNo(no), balance(opening), start(0), count(0) {}
    void deposit(double a) { if (a <= 0) return; balance += a; record('D', a); }
    bool withdraw(double a) { if (a <= 0 || a > balance) return false; balance -= a; record('W', a); return true; }
    void miniStatement() const {
        std::cout << "---- Mini statement (circular), A/c " << accNo << " ----\n";
        for (int i = 0; i < count; ++i) {
            const Transaction& t = last[(start + i) % MAX];
            std::cout << std::setw(2) << i + 1 << ". " << (t.type == 'D' ? "Deposit   " : "Withdrawal")
                      << std::setw(10) << std::fixed << std::setprecision(2) << t.amount << '\n';
        }
        std::cout << "Balance: " << balance << "\n\n";
    }
};

int main() {
    SavingsAccount acc(1001, 5000);
    for (int i = 1; i <= 12; ++i) {
        if (i % 3 == 0) acc.withdraw(100.0 * i);
        else            acc.deposit(250.0 * i);
    }
    acc.miniStatement();                // must be identical to account_shift.cpp output
}

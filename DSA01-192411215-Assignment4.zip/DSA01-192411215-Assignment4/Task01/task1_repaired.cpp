// Task 1.2 - Repaired design: common base class + derived classes
#include <iomanip>
#include <iostream>
#include <memory>
#include <string>
#include <utility>
#include <vector>

class Staff {                       // abstract base: common data + common interface
    std::string name_;
    int id_;
public:
    Staff(std::string name, int id) : name_(std::move(name)), id_(id) {}
    virtual ~Staff() = default;
    virtual double pay() const = 0;               // each category overrides
    virtual std::string category() const = 0;
    const std::string& name() const { return name_; }
    int id() const { return id_; }
    void print() const {
        std::cout << std::left << std::setw(14) << category() << std::setw(10) << name_
                  << std::setw(6) << id_ << std::right << std::fixed << std::setprecision(2)
                  << std::setw(12) << pay() << '\n';
    }
};

class SalariedStaff : public Staff {   // shared rule: basic + DA (written once)
    double basic_;
protected:
    static constexpr double DA_RATE = 0.42;   // named constant, no magic number
    double basicPlusDA() const { return basic_ + basic_ * DA_RATE; }
public:
    SalariedStaff(std::string n, int id, double basic) : Staff(std::move(n), id), basic_(basic) {}
};

class Professor : public SalariedStaff {
    double research_;
public:
    Professor(std::string n, int id, double basic, double research)
        : SalariedStaff(std::move(n), id, basic), research_(research) {}
    double pay() const override { return basicPlusDA() + research_; }
    std::string category() const override { return "Professor"; }
};

class LabAssistant : public SalariedStaff {
public:
    LabAssistant(std::string n, int id, double basic) : SalariedStaff(std::move(n), id, basic) {}
    double pay() const override { return basicPlusDA(); }
    std::string category() const override { return "LabAssistant"; }
};

class GuestFaculty : public Staff {
    double hours_, rate_;
public:
    GuestFaculty(std::string n, int id, double hours, double rate)
        : Staff(std::move(n), id), hours_(hours), rate_(rate) {}
    double pay() const override { return hours_ * rate_; }
    std::string category() const override { return "GuestFaculty"; }
};

int main() {
    std::vector<std::unique_ptr<Staff>> staff;      // all staff in ONE container / ONE loop
    staff.push_back(std::make_unique<Professor>("Meena", 101, 80000, 10000));
    staff.push_back(std::make_unique<LabAssistant>("Ravi", 102, 30000));
    staff.push_back(std::make_unique<GuestFaculty>("Anand", 201, 40, 1500));

    double total = 0;
    for (const auto& s : staff) { s->print(); total += s->pay(); }
    std::cout << "Total payroll: " << std::fixed << std::setprecision(2) << total << '\n';
}

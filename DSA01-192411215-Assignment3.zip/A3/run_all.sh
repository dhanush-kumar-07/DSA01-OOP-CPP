#!/bin/bash
# Compile and run every program. Usage:  bash run_all.sh
FLAGS="-std=c++17 -Wall -Wextra"
mkdir -p bin
run() {  # run <source> <name> [extra flags]
    src=$1; name=$2; shift 2
    echo "=================== $src ==================="
    if g++ $FLAGS "$@" "$src" -o bin/$name; then ./bin/$name; else echo ">>> compile failed (see message above)"; fi
    echo
}
run Q1/book.cpp                       q1_book
run Q1/book_default_args.cpp          q1_default_args
run Q1/explicit_demo.cpp              q1_explicit_ok
echo ">>> explicit_demo with -DUSE_EXPLICIT (expected compile ERROR)"
run Q1/explicit_demo.cpp              q1_explicit_err -DUSE_EXPLICIT
echo ">>> no_default_ctor (expected compile ERROR)"
run Q1/no_default_ctor.cpp            q1_nodefault
echo ">>> reorder_demo (expected -Wreorder warning)"
run Q1/reorder_demo.cpp               q1_reorder

echo ">>> Q2 shallow copy under AddressSanitizer (expected double-free error)"
run Q2/prescription_shallow.cpp       q2_shallow -fsanitize=address -g
run Q2/prescription_deep.cpp          q2_deep    -fsanitize=address -g
run Q2/prescription_experiments.cpp   q2_exp     -O2
run Q2/prescription_vector.cpp        q2_vec

run Q3/auditorium.cpp                 q3_aud     -fsanitize=address -g
echo ">>> forgotten delete (expected LeakSanitizer report)"
run Q3/auditorium_leak.cpp            q3_leak    -fsanitize=address -g
run Q3/logger_predict.cpp             q3_logger
run Q3/seatmap_alternatives.cpp       q3_alt

run Q4/money_complete.cpp             q4_complete
run Q4/money_full.cpp                 q4_full
run Q4/money_friend_vs_member.cpp     q4_friend
echo ">>> member-only operator+ (expected compile ERROR for 100 + m)"
run Q4/money_friend_vs_member.cpp     q4_member -DMEMBER_ONLY

run Q5/time_playlist.cpp              q5_time
run Q5/counter_predict.cpp            q5_counter
run Q5/timing.cpp                     q5_timing_O0 -O0
run Q5/timing.cpp                     q5_timing_O2 -O2

run Q6/text_main.cpp                  q6_text    -fsanitize=address -g
run Q6/text_compare.cpp               q6_compare -O2

run Q7/complex_rlc.cpp                q7_complex

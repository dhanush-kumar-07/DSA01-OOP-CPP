// Task 3 - Data types, sizes, ranges, type compatibility, precision and overflow
#include <cfloat>
#include <climits>
#include <cmath>
#include <iomanip>
#include <iostream>

int main()
{
    std::cout << "=== sizeof and ranges on this system ===\n";
    std::cout << "bool          " << sizeof(bool) << " byte(s)\n";
    std::cout << "char          " << sizeof(char) << "  [" << CHAR_MIN << ", " << CHAR_MAX << "]\n";
    std::cout << "int           " << sizeof(int) << "  [" << INT_MIN << ", " << INT_MAX << "]\n";
    std::cout << "unsigned int  " << sizeof(unsigned) << "  [0, " << UINT_MAX << "]\n";
    std::cout << "long long     " << sizeof(long long) << "  [" << LLONG_MIN << ", " << LLONG_MAX << "]\n";
    std::cout << "float         " << sizeof(float) << "  max " << FLT_MAX << "\n";
    std::cout << "double        " << sizeof(double) << "  max " << DBL_MAX << "\n";

    std::cout << "\n=== chosen types ===\n";
    std::cout << "fare/balance : long long (paise)   zone: enum class (int)   hour: int 0-23\n";
    std::cout << "journey count: long long           peak flag: bool\n";

    int i = 3; double d = 2.5; bool b = true;
    std::cout << "\nint + double + bool: " << i + d + b << "  (int->double, bool->int->double)\n";

    std::cout << "\n=== double rupees vs integer paise : n fares of Rs 12.10 ===\n";
    std::cout << std::setw(10) << "n" << std::setw(22) << "double total" << std::setw(16) << "paise total"
              << std::setw(18) << "abs error\n";
    long long ns[] = {10, 1000, 20000, 500000, 3000000};
    for (long long n : ns) {
        double dsum = 0.0;
        long long psum = 0;
        for (long long k = 0; k < n; ++k) { dsum += 12.10; psum += 1210; }
        double exact = static_cast<double>(psum) / 100.0;
        std::cout << std::setw(10) << n << std::setw(22) << std::setprecision(10) << std::fixed << dsum
                  << std::setw(16) << psum << std::setw(18) << std::setprecision(12) << std::fabs(dsum - exact) << '\n';
    }
    std::cout << std::defaultfloat;

    std::cout << "\n=== overflow: 3,000,000 journeys x 1580 paise (average) ===\n";
    long long exactTotal = 3000000LL * 1580;
    unsigned int wrapped = static_cast<unsigned int>(exactTotal);   // what a 32-bit int would hold (mod 2^32)
    std::cout << "exact (long long): " << exactTotal << "\n";
    std::cout << "INT_MAX          : " << INT_MAX << "  -> exact total is " << (exactTotal > INT_MAX ? "TOO BIG for int" : "ok") << "\n";
    std::cout << "32-bit wrapped   : " << static_cast<int>(wrapped) << "  (wrong, may even be negative)\n";
    std::cout << "Resolution: use long long paise (max " << LLONG_MAX << ").\n";
}

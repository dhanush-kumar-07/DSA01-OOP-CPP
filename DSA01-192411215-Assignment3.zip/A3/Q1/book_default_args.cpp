// Q1 alternative: ONE constructor with default arguments instead of overloads + delegation.
#include <iostream>
#include <stdexcept>
#include <string>
class Book {
    std::string title, author; int copies;
public:
    Book(std::string t = "Untitled", std::string a = "Unknown", int c = 0)
        : title(std::move(t)), author(std::move(a)), copies(c) {
        if (c < 0) throw std::invalid_argument("Invalid number of copies");  // checked in ONE place
    }
    void print() const { std::cout << title << " | " << author << " | " << copies << '\n'; }
};
int main() {
    Book a("Wings of Fire", "Kalam", 5), b("Malgudi Days"), c;
    a.print(); b.print(); c.print();
    try { Book d("X", "Y", -1); } catch (const std::exception& e) { std::cout << e.what() << '\n'; }
}

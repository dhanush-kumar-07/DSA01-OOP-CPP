// Task 4 - Corrected version: explicit casts and brace initialisation, no hidden conversions
#include <iostream>
int main()
{
    int a{7}, b{2};
    double c{static_cast<double>(a) / b};
    double d{static_cast<double>(a) / static_cast<double>(b)};
    std::cout << c << ' ' << d << '\n';

    char ch{static_cast<char>('A' + 2)};
    std::cout << ch << ' ' << static_cast<int>(ch) + 1 << '\n';

    bool flag{5 != 0};                              // bool flag{5}; would be a narrowing ERROR
    std::cout << flag << ' ' << std::boolalpha << flag << '\n';

    unsigned int u{1};
    int s{-1};
    std::cout << (s < static_cast<int>(u) ? "s < u" : "s >= u") << '\n';   // signed compare: correct

    // int x{3.7};  // ERROR: narrowing conversion from double to int (caught at compile time)
    int x{static_cast<int>(3.7)};                   // explicit: x == 3
    std::cout << "x = " << x << '\n';
}

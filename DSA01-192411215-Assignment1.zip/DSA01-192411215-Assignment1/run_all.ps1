# Windows PowerShell: compile and run every program, saving output to outputs\
# Usage (from repo root):  powershell -ExecutionPolicy Bypass -File .\run_all.ps1
$flags = @("-std=c++17","-Wall","-Wextra")
New-Item -ItemType Directory -Force -Path build, outputs | Out-Null
$programs = @(
 @("Task01","main.cpp",""), @("Task02","main.cpp",""), @("Task03","main.cpp",""),
 @("Task04","predict.cpp",""), @("Task04","fixed.cpp",""),
 @("Task05","predict.cpp",""), @("Task05","peak_check.cpp",""),
 @("Task06","complete_code.cpp",""), @("Task06","peak_boundary.cpp",""),
 @("Task07","procedural.cpp",""), @("Task07","oop.cpp",""), @("Task07","public_member.cpp",""),
 @("Task08","main.cpp","input.txt"), @("Task08","getline_version.cpp","input_lines.txt"),
 @("Task09","main.cpp",""), @("Task10","main.cpp",""), @("Task11","main.cpp",""), @("Task12","main.cpp","")
)
foreach ($p in $programs) {
  $d=$p[0]; $s=$p[1]; $in=$p[2]; $n=[IO.Path]::GetFileNameWithoutExtension($s)
  $exe = "build\${d}_$n.exe"
  Write-Host "===== $d\$s ====="
  g++ @flags "$d\$s" -o $exe
  Push-Location $d
  if ($in -ne "") { Get-Content $in | & "..\$exe" | Tee-Object "..\outputs\${d}_$n.txt" }
  else { & "..\$exe" | Tee-Object "..\outputs\${d}_$n.txt" }
  Pop-Location
}

// ===== TASK A5 - Recovery, rethrowing, stack unwinding (run this ONE file) =====
// Build: g++ -std=c++17 -Wall -Wextra -fsanitize=address -g main.cpp -o a5 && ./a5
// PART 1 is the Predict-the-Output program: write your prediction BEFORE running!
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

// ---------------- PART 1 : Predict the output ----------------
namespace predict {
struct Guard {
    std::string n;
    explicit Guard(const std::string& s) : n(s) {}
    ~Guard() { std::cout << '~' << n << ' '; }
};
void f()
{
    Guard g("f");
    throw 42;
}
void run()
{
    try {
        Guard m("main");
        f();
        std::cout << "not printed ";
    } catch (int x) {
        std::cout << "caught " << x;
    } catch (...) {
        std::cout << "other";
    }
    std::cout << '\n';
}
}

// ---------------- PART 2 : where to catch / log + rethrow / report ----------------
namespace design {
class BillingError : public std::runtime_error { public: using std::runtime_error::runtime_error; };
class ClaimError   : public BillingError       { public: using BillingError::BillingError; };

struct Trace { std::string n; explicit Trace(std::string s) : n(std::move(s)) {} ~Trace() { std::cout << "   ~" << n << '\n'; } };

void approve(double billed, double cover)                 // LOW level: detect and throw only
{
    Trace t("approve");
    if (billed > cover) throw ClaimError("claim above cover");
}
void processBill(int id, double billed, double cover)     // MIDDLE: log, add context, rethrow with throw;
{
    Trace t("processBill " + std::to_string(id));
    try { approve(billed, cover); }
    catch (const BillingError& e) {
        std::cout << "   [LOG bill " << id << "] " << e.what() << '\n';
        throw;                                            // same exception object continues upwards
    }
}
void run()
{
    double cases[][2] = {{40000, 50000}, {60000, 50000}};
    int id = 1;
    for (auto& c : cases) {
        try { processBill(id++, c[0], c[1]); std::cout << "   bill OK\n"; }
        catch (const ClaimError& e) {                     // TOP: report to the user, keep running
            std::cout << "   USER MESSAGE: claim rejected (" << e.what() << ")\n";
        }
    }
}
}

// ---------------- PART 3 : alternative = delete in every catch vs RAII ----------------
namespace raii {
void risky(bool fail) { if (fail) throw std::runtime_error("boom"); }
void manual(bool fail)
{
    double* buf = new double[100];
    try { risky(fail); }
    catch (...) { delete[] buf; throw; }                  // every new error path needs another delete
    delete[] buf;
}
void automatic(bool fail)
{
    std::vector<double> buf(100);                         // freed on ALL paths by the destructor
    risky(fail);
}
void run()
{
    for (auto f : {manual, automatic}) {
        try { f(true); } catch (const std::exception& e) { std::cout << "caught " << e.what() << " (no leak, ASan clean)\n"; }
    }
}
}

int main()
{
    std::cout << "=== PART 1 (predict) ===\n";
    predict::run();
    std::cout << "=== PART 2 (catch / log / rethrow / report) ===\n";
    design::run();
    std::cout << "=== PART 3 (manual delete vs RAII) ===\n";
    raii::run();
}

// Q3 - The ORIGINAL developer code. THIS FILE IS MEANT TO FAIL TO COMPILE.
// Save the compiler error message as evidence (screenshot).
#include <iostream>

double charge(double weight)                                       { return 50 + 20 * weight; }
double charge(double weight, bool express)                         { return 50 + 20 * weight + (express ? 30 : 0); }
double charge(double weight, bool express = false, bool insured = false)
                                                                   { return 50 + 20 * weight + (express ? 30 : 0) + (insured ? 10 : 0); }

int main() {
    std::cout << charge(2.0) << '\n';          // ambiguous: overload 1 vs overload 3
    std::cout << charge(2.0, true) << '\n';    // ambiguous: overload 2 vs overload 3
}

#!/bin/bash
# Linux/macOS/Git-Bash: compile and run every program, saving output to outputs/
set -u
F="-std=c++17 -Wall -Wextra"
mkdir -p build outputs
run() { d=$1; s=$2; in=${3:-}; n=${s%.cpp}
  echo "===== $d/$s ====="
  g++ $F "$d/$s" -o "build/${d}_$n" || return
  if [ -n "$in" ]; then (cd "$d" && "../build/${d}_$n" < "$in") | tee "outputs/${d}_$n.txt"
  else (cd "$d" && "../build/${d}_$n") | tee "outputs/${d}_$n.txt"; fi; }
run Task01 main.cpp; run Task02 main.cpp; run Task03 main.cpp
run Task04 predict.cpp; run Task04 fixed.cpp
run Task05 predict.cpp; run Task05 peak_check.cpp
run Task06 complete_code.cpp; run Task06 peak_boundary.cpp
run Task07 procedural.cpp; run Task07 oop.cpp; run Task07 public_member.cpp
run Task08 main.cpp input.txt; run Task08 getline_version.cpp input_lines.txt
run Task09 main.cpp; run Task10 main.cpp; run Task11 main.cpp; run Task12 main.cpp

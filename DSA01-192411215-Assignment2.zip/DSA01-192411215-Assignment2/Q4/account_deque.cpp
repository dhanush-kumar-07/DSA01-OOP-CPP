// Q4 - Alternative: std::deque (push_back / pop_front)
#include <iostream>
#include <deque>
#include <iomanip>

struct Transaction { char type; double amount; };

class SavingsAccount {
    static const std::size_t MAX = 10;
    int accNo; double balance; std::deque<Transaction> last;
    void record(char t, double a) {
        if (last.size() == MAX) last.pop_front();     // O(1)
        last.push_back({t, a});                       // O(1)
    }
public:
    SavingsAccount(int n, double b) : accNo(n), balance(b) {}
    void deposit(double a) { balance += a; record('D', a); }
    bool withdraw(double a) { if (a > balance) return false; balance -= a; record('W', a); return true; }
    void miniStatement() const {
        std::cout << "---- Mini statement (deque), A/c " << accNo << " ----\n";
        int i = 1;
        for (const auto& t : last)
            std::cout << std::setw(2) << i++ << ". " << (t.type == 'D' ? "Deposit   " : "Withdrawal")
                      << std::setw(10) << std::fixed << std::setprecision(2) << t.amount << '\n';
        std::cout << "Balance: " << balance << "\n\n";
    }
};

int main() {
    SavingsAccount acc(1001, 5000);
    for (int i = 1; i <= 12; ++i) { if (i % 3 == 0) acc.withdraw(100.0 * i); else acc.deposit(250.0 * i); }
    acc.miniStatement();
}

// Q5 - Tickets created inside a function called twice: the static count is NOT reset
// when the local objects are destroyed.
#include <iostream>
#include <string>
class BusTicket {
    static int issued;
    static const int CAPACITY = 3;
    int seat; std::string name;
public:
    explicit BusTicket(const std::string& n) : seat(0), name(n) { if (issued < CAPACITY) seat = ++issued; }
    ~BusTicket() { std::cout << "  (destroying " << name << ")\n"; }   // destructor does not touch 'issued'
    static int count() { return issued; }
    void print() const { std::cout << name << ": " << (seat ? "Seat " + std::to_string(seat) : std::string("Waiting")) << '\n'; }
};
int BusTicket::issued = 0;

void bookTwo(const std::string& a, const std::string& b) {
    BusTicket t1(a), t2(b);
    t1.print(); t2.print();
    std::cout << "  issued so far: " << BusTicket::count() << '\n';
}   // t1, t2 destroyed here

int main() {
    std::cout << "Call 1:\n"; bookTwo("Asha", "Bala");
    std::cout << "Call 2:\n"; bookTwo("Chitra", "Dev");
    std::cout << "Final issued count: " << BusTicket::count() << '\n';
}

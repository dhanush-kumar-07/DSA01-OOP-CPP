// Q5 - Alternative: a TicketOffice object instead of a static member (supports two buses)
#include <iostream>
#include <string>

class TicketOffice {
    int issued = 0, capacity;
public:
    explicit TicketOffice(int cap) : capacity(cap) {}
    int nextSeat() { return issued < capacity ? ++issued : 0; }
    int count() const { return issued; }
};

class BusTicket {
    int seat; std::string name;
public:
    BusTicket(TicketOffice& office, const std::string& n) : seat(office.nextSeat()), name(n) {}
    void print() const { std::cout << name << ": " << (seat ? "Seat " + std::to_string(seat) : std::string("Waiting")) << '\n'; }
};

int main() {
    TicketOffice bus1(3), bus2(2);                  // two independent buses at the same time
    BusTicket a(bus1, "Asha"), b(bus1, "Bala"), c(bus1, "Chitra"), d(bus1, "Dev");
    BusTicket e(bus2, "Esha"), f(bus2, "Farid"), g(bus2, "Gita");
    for (const BusTicket* t : {&a, &b, &c, &d}) t->print();
    std::cout << "Bus1 issued: " << bus1.count() << "\n";
    for (const BusTicket* t : {&e, &f, &g}) t->print();
    std::cout << "Bus2 issued: " << bus2.count() << "\n";
}

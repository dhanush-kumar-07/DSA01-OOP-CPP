// Q1 - Constructors and constructor overloading (Library Book Records)
#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>

class Book {
    std::string title;   // declared first  -> initialised first
    std::string author;  // declared second
    int copies;          // declared third

    // single place where the number of copies is validated
    static int checkCopies(int c) {
        if (c < 0)
            throw std::invalid_argument("Invalid number of copies: " + std::to_string(c));
        return c;
    }

public:
    // Parameterised constructor: the "main" constructor, everything else delegates to it
    Book(std::string t, std::string a, int c)
        : title(std::move(t)), author(std::move(a)), copies(checkCopies(c)) {
        std::cout << "  [parameterised ctor] " << title << '\n';
    }
    // Donated book: only a title is known (delegating constructor)
    explicit Book(std::string t) : Book(std::move(t), "Unknown", 1) {
        std::cout << "  [donated ctor] done\n";
    }
    // Empty record to be filled later (delegating constructor)
    Book() : Book("Untitled", "Unknown", 0) {
        std::cout << "  [default ctor] done\n";
    }

    void print() const {
        std::cout << "  Book{title=\"" << title << "\", author=\"" << author
                  << "\", copies=" << copies << "}\n";
    }
};

int main() {
    std::cout << "1) Full details:\n";
    Book b1("Wings of Fire", "A.P.J. Abdul Kalam", 5);
    b1.print();

    std::cout << "2) Donated book (title only):\n";
    Book b2("Malgudi Days");
    b2.print();

    std::cout << "3) Empty record:\n";
    Book b3;
    b3.print();

    std::cout << "4) Negative number of copies:\n";
    try {
        Book bad("Broken", "Nobody", -3);
        bad.print();
    } catch (const std::exception& e) {
        std::cout << "  Rejected -> " << e.what() << '\n';
    }
    std::cout << "No Book with an invalid number of copies can exist.\n";
    return 0;
}

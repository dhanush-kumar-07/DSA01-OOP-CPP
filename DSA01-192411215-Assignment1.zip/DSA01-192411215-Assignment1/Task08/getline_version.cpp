// Task 8 - Alternative: std::getline + std::stoi inside try/catch (same input.txt)
#include <iostream>
#include <stdexcept>
#include <string>

bool readInt(const std::string& prompt, int lo, int hi, int& out)
{
    std::string line;
    while (true) {
        std::cout << prompt;
        if (!std::getline(std::cin, line)) return false;
        try {
            std::size_t pos = 0;
            int v = std::stoi(line, &pos);
            if (pos != line.size()) throw std::invalid_argument("trailing characters");
            if (v < lo || v > hi) throw std::out_of_range("range");
            out = v;
            std::cout << v << '\n';
            return true;
        } catch (const std::invalid_argument&) {
            std::cout << "\n  Invalid: '" << line << "' is not a whole number.\n";
        } catch (const std::out_of_range&) {
            std::cout << "\n  Out of range.\n";
        }
    }
}

int main()
{
    int rupees, n;
    if (!readInt("Starting balance (Rs): ", 50, 100000, rupees)) return 1;
    if (!readInt("Number of journeys: ", 1, 20, n)) return 1;
    long long balance = rupees * 100LL;
    for (int i = 1; i <= n; ++i) {
        int zone, hour;
        if (!readInt("Zone (0-2): ", 0, 2, zone)) break;
        if (!readInt("Hour (0-23): ", 0, 23, hour)) break;
        bool peak = (hour >= 8 && hour < 10) || (hour >= 17 && hour < 20);
        long long f = 1000LL * (zone + 1);
        if (peak) f += f * 20 / 100;
        if (balance - f >= 5000) { balance -= f; std::cout << "paid " << f << " balance " << balance << '\n'; }
        else std::cout << "denied balance " << balance << '\n';
    }
}

// Task 6 Stage 5 - demonstration: rent each type, late return, add ElectricBus without touching existing classes
#include "electric_bus.h"
int main() {
    std::cout << std::fixed << std::setprecision(2);
    Fleet fleet;
    fleet.add(new Bicycle("BIC-001", 150));
    fleet.add(new TwoWheeler("TN01-2W", 400, 80, ServiceDate(15, 1, 2027)));
    fleet.add(new Car("TN02-CAR", 1500, 60, ServiceDate(1, 2, 2027), 5));
    fleet.add(new ElectricCar("TN03-EV", 2000, 90, ServiceDate(10, 3, 2027), 5, 40));

    std::cout << "== Fleet ==\n"; fleet.list();

    std::cout << "\n== Renting each type ==\n";
    fleet.rent("BIC-001", 2); fleet.rent("TN01-2W", 3); fleet.rent("TN02-CAR", 2); fleet.rent("TN03-EV", 2);
    std::cout << "Renting TN02-CAR again: " << (fleet.rent("TN02-CAR", 1) ? "ok" : "refused (already rented)") << '\n';
    fleet.list();

    std::cout << "\n== Returns ==\n";
    std::cout << "Bicycle   (on time)          : " << fleet.giveBack("BIC-001", 2, 0)  << '\n';
    std::cout << "TwoWheeler(on time, 4 L)     : " << fleet.giveBack("TN01-2W", 3, 4)  << '\n';
    std::cout << "Car       (1 day LATE, 20 L) : " << fleet.giveBack("TN02-CAR", 3, 20) << '\n';
    std::cout << "ElectricCar(on time, 25 kWh) : " << fleet.giveBack("TN03-EV", 2, 25) << '\n';

    std::cout << "\n== Adding a NEW type: ElectricBus (no existing class changed) ==\n";
    fleet.add(new ElectricBus("TN04-BUS", 6000, 100, ServiceDate(5, 4, 2027), 40, 200, 40));
    fleet.rent("TN04-BUS", 1);
    std::cout << "ElectricBus (1 day LATE, 120 kWh): " << fleet.giveBack("TN04-BUS", 2, 120) << '\n';
    std::cout << '\n'; fleet.list();
}
